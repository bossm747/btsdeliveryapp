# 3D Realistic Bee

A Pen created on CodePen.

Original URL: [https://codepen.io/Marc-Agbay-the-scripter/pen/raOqNVZ](https://codepen.io/Marc-Agbay-the-scripter/pen/raOqNVZ).

Webgl Bee made using ThreeJs