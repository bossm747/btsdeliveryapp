import React from 'react';

import {constants} from '@/constants';

type Props = {
  label: string;
  onClick?: () => void;
  colorScheme?: 'primary' | 'secondary';
  containerStyle?: React.CSSProperties;
};

export const Button: React.FC<Props> = ({
  label,
  onClick,
  containerStyle,
  colorScheme = 'primary',
}) => {
  return (
    <div style={{width: '100%'}}>
      <button
        type='button'
        style={{
          backgroundColor:
            colorScheme === 'primary'
              ? constants.colors.SEA_GREEN_COLOR
              : '#E8F9F1',
          width: '100%',
          borderRadius: 10,
          color: '#fff',
          height: 50,
          ...constants.flex.FLEX_ROW_CENTER,
          ...containerStyle,
        }}
        onClick={onClick}
      >
        <span
          style={{
            fontWeight: 700,

            color:
              colorScheme === 'primary'
                ? '#fff'
                : constants.colors.SEA_GREEN_COLOR,
            fontSize: 16,
            textTransform: 'capitalize',
          }}
        >
          {label}
        </span>
      </button>
    </div>
  );
};
