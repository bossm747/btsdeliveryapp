import React from 'react';

import {stores} from '@/stores';
import {DishType} from '@/types';
import {constants} from '@/constants';

type Props = {
  dish: DishType;
};

export const AddToCart: React.FC<Props> = ({dish}) => {
  const {showToast} = stores.useToastStore();
  const {addToCart, list: cart} = stores.useCartStore();
  const inCart = cart.find((item) => item.id === dish?.id);

  return (
    <button
      style={{
        backgroundColor: '#E8F9F1',
        height: 32,
        borderRadius: 5,
        width: '100%',
        ...constants.flex.FLEX_ROW_CENTER,
      }}
      onClick={(e) => {
        e.stopPropagation();
        e.preventDefault();

        const currentQuantity = inCart?.quantity ?? 0;
        addToCart(dish);
        showToast(`${dish.name} added to cart (${currentQuantity + 1})`);
      }}
    >
      <span
        style={{
          fontSize: 12,
          color: constants.colors.SEA_GREEN_COLOR,
          fontWeight: 500,
        }}
      >
        Add to Cart
      </span>
    </button>
  );
};
