import React from 'react';

import {constants} from '@/constants';

type Props = {
  title?: string;
  onClick?: () => void;
  containerStyle?: React.CSSProperties;
};

export const BlockHeading: React.FC<Props> = ({
  title,
  onClick,
  containerStyle,
}) => {
  return (
    <div
      style={{
        paddingLeft: 20,
        paddingRight: 20,
        ...constants.flex.FLEX_ROW_BETWEEN,
        ...containerStyle,
      }}
    >
      <h2
        style={{
          fontWeight: 600,
          color: constants.colors.MAIN_DARK_COLOR,
          fontSize: 18,
          textTransform: 'capitalize',
        }}
      >
        {title}
      </h2>
      {onClick && (
        <button
          onClick={onClick}
          style={{
            color: constants.colors.SEA_GREEN_COLOR,
            fontSize: 14,
            fontWeight: 400,
            textDecoration: 'none',
          }}
        >
          View All
        </button>
      )}
    </div>
  );
};
