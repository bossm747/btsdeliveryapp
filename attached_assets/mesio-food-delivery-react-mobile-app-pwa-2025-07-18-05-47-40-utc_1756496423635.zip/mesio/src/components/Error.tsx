import React from 'react';

import {hooks} from '@/hooks';

export const Error: React.FC = () => {
  const {navigate} = hooks.useRouter();

  return (
    <div
      style={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'column',
        height: '100%',
        width: '100%',
      }}
    >
      <span>Error</span>
      <button
        onClick={() => {
          navigate(-1);
        }}
      >
        <span>go back</span>
      </button>
    </div>
  );
};
