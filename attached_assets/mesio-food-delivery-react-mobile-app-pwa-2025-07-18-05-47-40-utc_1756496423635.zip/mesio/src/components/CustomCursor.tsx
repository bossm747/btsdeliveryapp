'use client';

import React from 'react';
import {utils} from '@/utils';
import {createPortal} from 'react-dom';
import {isBrowser} from 'react-device-detect';

import {useEffect, useState} from 'react';

export const CustomCursor: React.FC = () => {
  const [position, setPosition] = useState({x: 0, y: 0});
  const [visible, setVisible] = useState(false);
  const [activated, setActivated] = useState(false);

  useEffect(() => {
    const moveCursor = (e: MouseEvent) => {
      setPosition({x: e.clientX, y: e.clientY});
      setActivated(true);
      const inBounds =
        e.clientX > 0 &&
        e.clientY > 0 &&
        e.clientX < window.innerWidth - 1 &&
        e.clientY < window.innerHeight - 1;
      setVisible(inBounds);
    };
    const handleMouseLeave = () => setVisible(false);
    const handleBlur = () => setVisible(false);

    window.addEventListener('mousemove', moveCursor);
    document.addEventListener('mouseleave', handleMouseLeave);
    window.addEventListener('blur', handleBlur);

    return () => {
      window.removeEventListener('mousemove', moveCursor);
      document.removeEventListener('mouseleave', handleMouseLeave);
      window.removeEventListener('blur', handleBlur);
    };
  }, []);

  if (!activated) return null;

  const cursorElement = (
    <div
      style={{
        position: 'fixed',
        top: position.y - 8,
        left: position.x - 8,
        width: 15,
        height: 15,
        borderRadius: '50%',
        backgroundColor: 'black',
        pointerEvents: 'none',
        zIndex: 9999999,
        transition: 'opacity 0.3s, transform 0.1s ease-out',
        opacity: visible ? 0.65 : 0,
        transform: visible ? 'scale(1)' : 'scale(0.8)',
      }}
      className='custom-cursor'
    />
  );

  if (isBrowser && !utils.isEmulator()) {
    return createPortal(cursorElement, document.body);
  }
};
