import React from 'react';

import Check from '@/assets/svg/check.svg?react';

import {constants} from '@/constants';

type Props = {
  checked?: boolean;
};

export const Checkbox: React.FC<Props> = ({checked}) => {
  return (
    <div
      style={{
        width: 16,
        height: 16,
        borderWidth: 1,
        borderColor: constants.colors.SEA_GREEN_COLOR,
        borderRadius: 3,
        borderStyle: 'solid',
        ...constants.flex.FLEX_ROW_CENTER,
      }}
    >
      {checked && <Check />}
    </div>
  );
};
