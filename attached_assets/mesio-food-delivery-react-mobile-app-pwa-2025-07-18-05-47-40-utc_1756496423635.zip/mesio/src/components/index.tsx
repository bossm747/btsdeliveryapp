import {Input} from '@/components/Input';
import {Toast} from '@/components/Toast';
import {Error} from '@/components/Error';
import {Header} from '@/components/Header';
import {Button} from '@/components/Button';
import {Loader} from '@/components/Loader';
import {Rating} from '@/components/Rating';
import {Checkbox} from '@/components/Checkbox';
import {AddToCart} from '@/components/AddToCart';
import {InWishlist} from '@/components/InWishlist';
import {RatingStars} from '@/components/RatingStars';
import {CustomCursor} from '@/components/CustomCursor';
import {BlockHeading} from '@/components/BlockHeading';
import {SafeAreaView} from '@/components/SafeAreaView';
import {BottomTabBar} from '@/components/BottomTabBar';
import {AddToCartIcon} from '@/components/AddToCartIcon';
import {MotionWrapper} from '@/components/MotionWrapper';
import {BurgerContacts} from '@/components/BurgerContacts';
import {SafeAreaInsetBottom} from '@/components/SafeAreaInsetBottom';

export const components = {
  Input,
  Toast,
  Error,
  Header,
  Button,
  Loader,
  Rating,
  Checkbox,
  AddToCart,
  InWishlist,
  RatingStars,
  BlockHeading,
  BottomTabBar,
  CustomCursor,
  SafeAreaView,
  MotionWrapper,
  AddToCartIcon,
  BurgerContacts,
  SafeAreaInsetBottom,
};
