import React from 'react';

import GoBack from '@/assets/svg/go-back.svg?react';
import BurgerSvg from '@/assets/svg/burger.svg?react';
import ShoppingBagSvg from '@/assets/svg/shopping-bag.svg?react';

import {hooks} from '@/hooks';
import {stores} from '@/stores';
import {constants} from '@/constants';

type Props = {
  title?: string;
  showBasket?: boolean;
  showGoBack?: boolean;
  showBurger?: boolean;
  titleStyle?: React.CSSProperties;
};

export const Header: React.FC<Props> = ({
  title,
  showGoBack,
  showBasket,
  showBurger,
  titleStyle,
}) => {
  const {navigate} = hooks.useRouter();
  const canGoBack = showGoBack && window.history.length > 1;
  const {total, list: cart} = stores.useCartStore();
  const {setVisible} = stores.useModalStore();

  const renderGoBack = () => {
    if (!showGoBack && !canGoBack) return null;

    return (
      <button
        style={{paddingLeft: 20, paddingRight: 20}}
        onClick={() => {
          navigate(-1);
        }}
      >
        <GoBack
          color={constants.colors.MAIN_DARK_COLOR}
          stroke={constants.colors.MAIN_DARK_COLOR}
        />
      </button>
    );
  };

  const renderBurger = () => {
    if (!showBurger) return null;
    return (
      <button
        style={{paddingLeft: 20, paddingRight: 20}}
        onClick={() => {
          setVisible(true);
        }}
      >
        <BurgerSvg />
      </button>
    );
  };

  const renderTitle = () => {
    return (
      <div
        style={{
          position: 'absolute',
          left: '50%',
          transform: 'translateX(-50%)',
        }}
      >
        <h4
          style={{
            color: constants.colors.MAIN_DARK_COLOR,
            ...titleStyle,
          }}
        >
          {title}
        </h4>
      </div>
    );
  };

  const renderBasket = () => {
    if (!showBasket) return null;
    return (
      <button
        style={{
          paddingLeft: 20,
          paddingRight: 20,
        }}
        onClick={() => {
          if (cart.length > 0) {
            navigate(constants.routes.ORDER);
          } else {
            window.alert('Your cart is empty');
          }
        }}
      >
        <div
          style={{
            backgroundColor: constants.colors.RED_COLOR,
            height: 20,
            borderRadius: 10,
            position: 'absolute',
            top: 18,
            right: 34,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            paddingLeft: 6,
            paddingRight: 6,
          }}
        >
          <span
            style={{
              color: constants.colors.WHITE_COLOR,
              fontSize: 10,
              fontWeight: 600,
            }}
          >
            ${total > 0 ? total.toFixed(2) : '0'}
          </span>
        </div>
        <ShoppingBagSvg width={22} />
      </button>
    );
  };

  const renderContent = () => {
    return (
      <header
        style={{
          position: 'fixed',
          top: 0,
          left: '50%',
          transform: 'translateX(-50%)',
          width: '100%',
          zIndex: 3,
          height: constants.sizes.HEADER_HEIGHT,
          maxWidth: constants.sizes.SCREEN_WIDTH,
          margin: '0 auto',
          ...constants.flex.FLEX_ROW_BETWEEN,
          backgroundColor: constants.colors.WHITE_COLOR,
        }}
      >
        {renderBurger()}
        {renderGoBack()}
        {renderTitle()}
        {renderBasket()}
      </header>
    );
  };

  return renderContent();
};
