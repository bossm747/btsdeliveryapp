import React, {useState} from 'react';

import {constants} from '@/constants';

type Props = {
  onClick?: () => void;
  placeholder?: string;
  value?: string;
  isValid?: boolean;
  inputType?: 'text' | 'password';
  containerStyle?: React.CSSProperties;
  className?: string;
  leftIcon?: React.ReactNode;
};

export const Input: React.FC<Props> = ({
  placeholder,
  containerStyle,
  onClick,
  value,
  inputType = 'text',
}) => {
  const [visible, _] = useState(false);

  const isPlaceholder = !value;

  return (
    <button
      style={{
        backgroundColor: constants.colors.LIGHT_GRAY_COLOR,
        width: '100%',
        borderRadius: 10,
        display: 'flex',
        alignItems: 'center',
        height: 50,
        paddingLeft: 20,
        border: '1px solid #EEEEEE',
        cursor: 'pointer',
        ...containerStyle,
      }}
      onClick={onClick}
      type='button'
    >
      <span
        style={{
          fontSize: 14,
          lineHeight: 1.6,
          marginRight: 'auto',
          paddingRight: 20,
          background: 'none',
          border: 'none',
          color: isPlaceholder
            ? constants.colors.TEXT_COLOR
            : constants.colors.MAIN_DARK_COLOR,
        }}
      >
        {inputType === 'password' && !visible
          ? value
            ? '•'.repeat(value.length)
            : placeholder || 'Enter text...'
          : value || placeholder || 'Enter text...'}
      </span>
    </button>
  );
};
