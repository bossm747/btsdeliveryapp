import React from 'react';
import {constants} from '@/constants';
import {useToastStore} from '@/stores/useToastStore';

export const Toast: React.FC = () => {
  const {message, visible, hideToast} = useToastStore();

  if (!message && !visible) return null;

  return (
    <div
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        maxWidth: constants.sizes.SCREEN_WIDTH,
        margin: '0 auto',
        backgroundColor: '#0F1620',
        borderBottom: `1px solid rgba(255, 255, 255, 0.1)`,
        transform: visible ? 'translateY(0)' : 'translateY(-100%)',
        transition: 'all 0.5s ease-in-out',
        color: 'white',
        padding: '12px 24px',
        zIndex: 10000,
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
      }}
    >
      <span
        className='number-of-lines-1'
        style={{fontSize: 14, color: constants.colors.LIGHT_GRAY_COLOR}}
      >
        {message}
      </span>
      <button
        onClick={hideToast}
        type='button'
        style={{
          marginLeft: 10,
          fontSize: 14,
          color: constants.colors.LIGHT_GRAY_COLOR,
          cursor: 'pointer',
        }}
      >
        close
      </button>
    </div>
  );
};
