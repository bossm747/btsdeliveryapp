import React from 'react';
import {isMobile} from 'react-device-detect';

import {hooks} from '../hooks';
import {stores} from '@/stores';
import {constants} from '@/constants';

type Props = {
  containerStyle?: React.CSSProperties;
  tabsContainerStyle?: React.CSSProperties;
};

export const BottomTabBar: React.FC<Props> = ({
  containerStyle,
  tabsContainerStyle,
}) => {
  const {location, navigate} = hooks.useRouter();
  const {list: cart} = stores.useCartStore();
  const {list: wishlist} = stores.useWishlistStore();

  return (
    <div
      style={{
        maxWidth: isMobile ? '100%' : constants.sizes.SCREEN_WIDTH,
        zIndex: 100,
        position: 'fixed',
        left: 0,
        right: 0,
        margin: '0 auto',
        bottom: 'env(safe-area-inset-bottom)',
        paddingLeft: 10,
        paddingRight: 10,
        backgroundColor: constants.colors.WHITE_COLOR,
        borderTopWidth: 1,
        borderTopColor: '#F3F4F5',
        borderTopStyle: 'solid',
        ...containerStyle,
      }}
    >
      <footer
        style={{
          backgroundColor: 'var(--main-dark-color)',
          borderRadius: 70,
          width: '100%',
          height: constants.sizes.TAB_BAR_HEIGHT,
          ...constants.flex.FLEX_ROW_SPACE_AROUND,
          ...tabsContainerStyle,
        }}
      >
        {constants.tabs.map((tab, index) => {
          const color =
            location.pathname === tab.route
              ? constants.colors.SEA_GREEN_COLOR
              : location.pathname === constants.routes.CART_EMPTY &&
                tab.route === constants.routes.ORDER
              ? constants.colors.SEA_GREEN_COLOR
              : location.pathname === constants.routes.WISHLIST_EMPTY &&
                tab.route === constants.routes.WISHLIST
              ? constants.colors.SEA_GREEN_COLOR
              : constants.colors.TEXT_COLOR;
          const Icon = tab.icon;
          return (
            <button
              key={index}
              onClick={() => {
                if (cart.length === 0 && tab.route === constants.routes.ORDER) {
                  navigate(constants.routes.CART_EMPTY);
                  return;
                }

                if (
                  wishlist.length === 0 &&
                  tab.route === constants.routes.WISHLIST
                ) {
                  navigate(constants.routes.WISHLIST_EMPTY);
                  return;
                }

                navigate(tab.route);
              }}
              type='button'
            >
              <Icon color={color} />
            </button>
          );
        })}
      </footer>
    </div>
  );
};
