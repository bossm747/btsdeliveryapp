const h2 = {
  fontSize: 22,
  fontWeight: 700,
};

export const typography = {h2};
