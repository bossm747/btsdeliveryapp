const boxShadow = {
  boxShadow: '0px 0px 25px rgba(211, 209, 216, 0.25)',
};

export const styles = {
  boxShadow,
};
