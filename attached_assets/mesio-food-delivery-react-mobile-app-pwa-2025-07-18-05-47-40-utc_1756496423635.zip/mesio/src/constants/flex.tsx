const FLEX_ROW_BETWEEN = {
  display: 'flex',
  alignItems: 'center',
  flexDirection: 'row',
  justifyContent: 'space-between',
} as const;

const FLEX_ROW_CENTER = {
  display: 'flex',
  alignItems: 'center',
  flexDirection: 'row',
  justifyContent: 'center',
} as const;

const FLEX_ROW = {
  display: 'flex',
  alignItems: 'center',
  flexDirection: 'row',
} as const;

const FLEX_COLUMN = {
  display: 'flex',
  flexDirection: 'column',
} as const;

const FLEX_ROW_SPACE_AROUND = {
  display: 'flex',
  alignItems: 'center',
  flexDirection: 'row',
  justifyContent: 'space-around',
} as const;

const FLEX_COLUMN_CENTER = {
  display: 'flex',
  alignItems: 'center',
  flexDirection: 'column',
  justifyContent: 'center',
} as const;

export const flex = {
  FLEX_ROW,
  FLEX_COLUMN,
  FLEX_ROW_CENTER,
  FLEX_ROW_BETWEEN,
  FLEX_COLUMN_CENTER,
  FLEX_ROW_SPACE_AROUND,
};
