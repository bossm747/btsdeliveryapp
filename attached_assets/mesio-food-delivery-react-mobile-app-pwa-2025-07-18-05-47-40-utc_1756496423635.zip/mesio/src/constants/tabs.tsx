import {routes} from './routes';

import BagIcon from '@/assets/svg/bag.svg?react';
import UserIcon from '@/assets/svg/user.svg?react';
import HomeIcon from '@/assets/svg/home.svg?react';
import HeartIcon from '@/assets/svg/heart.svg?react';

export const tabs = [
  {
    id: 1,
    route: routes.HOME,
    icon: HomeIcon,
  },
  {
    id: 2,
    route: routes.ORDER,
    icon: BagIcon,
  },
  {
    id: 3,
    route: routes.WISHLIST,
    icon: HeartIcon,
  },
  {
    id: 4,
    route: routes.PROFILE,
    icon: UserIcon,
  },
];
