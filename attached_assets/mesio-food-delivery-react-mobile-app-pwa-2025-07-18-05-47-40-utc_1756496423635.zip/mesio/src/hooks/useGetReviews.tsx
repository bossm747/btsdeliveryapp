import axios from 'axios';
import {useQuery} from '@tanstack/react-query';

import {URLS} from '@/config';

export const useGetReviews = () => {
  const getReviews = async () => {
    try {
      const response = await axios.get(URLS.GET_REVIEWS);

      if (!response.data) {
        throw new Error('No data in response');
      }

      const reviews = response.data.reviews || response.data || [];

      return reviews;
    } catch (error) {
      console.error('API request failed:', error);
      throw error;
    }
  };

  const queryResult = useQuery({
    queryKey: ['reviews'],
    queryFn: getReviews,
    refetchOnWindowFocus: false,
    refetchOnReconnect: false,
    retry: 1,
    staleTime: 1000 * 60 * 5,
    gcTime: 1000 * 60 * 30,
  });

  return queryResult;
};
