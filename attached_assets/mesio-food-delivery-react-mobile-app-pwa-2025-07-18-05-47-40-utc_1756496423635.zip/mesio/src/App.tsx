import {useEffect} from 'react';
import {AnimatePresence} from 'motion/react';
import {useLocation, Routes, Route} from 'react-router-dom';
import {QueryClient, QueryClientProvider} from '@tanstack/react-query';

import {stores} from '@/stores';
import {screens} from '@/screens';
import {constants} from '@/constants';
import {components} from '@/components';

const queryClient = new QueryClient();

function App() {
  const location = useLocation();
  const {hideToast} = stores.useToastStore();

  useEffect(() => {
    hideToast();
  }, [location.pathname]);

  return (
    <QueryClientProvider client={queryClient}>
      <AnimatePresence mode='wait'>
        <Routes
          location={location}
          key={location.pathname}
        >
          <Route
            key='onboarding'
            path={constants.routes.ONBOARDING}
            element={<screens.Onboarding />}
          />
          <Route
            key='sign-in'
            path={constants.routes.SIGN_IN}
            element={<screens.SignIn />}
          />
          <Route
            key='comment-reply'
            path={constants.routes.COMMENT_REPLY}
            element={<screens.CommentReply />}
          />
          <Route
            key='shop'
            path={constants.routes.SHOP}
            element={<screens.Shop />}
          />
          <Route
            key='shop-category'
            path={constants.routes.SHOP_CATEGORY}
            element={<screens.ShopCategory />}
          />
          <Route
            key='sign-up'
            path={constants.routes.SIGN_UP}
            element={<screens.SignUp />}
          />
          <Route
            key='reviews'
            path={constants.routes.REVIEWS}
            element={<screens.Reviews />}
          />
          <Route
            key='leave-review'
            path={constants.routes.LEAVE_A_REVIEW}
            element={<screens.LeaveAReview />}
          />
          <Route
            key='wishlist-empty'
            path={constants.routes.WISHLIST_EMPTY}
            element={<screens.WishlistEmpty />}
          />
          <Route
            key='forgot-password'
            path={constants.routes.FORGOT_PASSWORD}
            element={<screens.ForgetPassword />}
          />
          <Route
            key='dish'
            path={constants.routes.DISH}
            element={<screens.Dish />}
          />
          <Route
            key='new-password'
            path={constants.routes.NEW_PASSWORD}
            element={<screens.NewPassword />}
          />
          <Route
            key='cart-empty'
            path={constants.routes.CART_EMPTY}
            element={<screens.CartEmpty />}
          />
          <Route
            key='verify-phone'
            path={constants.routes.VERIFY_YOUR_PHONE_NUMBER}
            element={<screens.VerifyYourPhoneNumber />}
          />
          <Route
            key='account-created'
            path={constants.routes.ACCOUNT_CREATED}
            element={<screens.AccountCreated />}
          />
          <Route
            key='home'
            path={constants.routes.HOME}
            element={<screens.Home />}
          />
          <Route
            key='checkout'
            path={constants.routes.CHECKOUT}
            element={<screens.Checkout />}
          />
          <Route
            key='profile'
            path={constants.routes.PROFILE}
            element={<screens.Profile />}
          />
          <Route
            key='edit-profile'
            path={constants.routes.EDIT_PROFILE}
            element={<screens.EditProfile />}
          />
          <Route
            key='change-password'
            path={constants.routes.CHANGE_PASSWORD}
            element={<screens.ChangePassword />}
          />
          <Route
            key='promocodes-empty'
            path={constants.routes.MY_PROMOCODES_EMPTY}
            element={<screens.MyPromocodesEmpty />}
          />
          <Route
            key='order-successful'
            path={constants.routes.ORDER_SUCCESSFUL}
            element={<screens.OrderSuccessful />}
          />
          <Route
            key='confirmation-code'
            path={constants.routes.CONFIRMATION_CODE}
            element={<screens.ConfirmationCode />}
          />
          <Route
            key='my-promocodes'
            path={constants.routes.MY_PROMOCODES}
            element={<screens.MyPromocodes />}
          />
          <Route
            key='order-history'
            path={constants.routes.ORDER_HISTORY}
            element={<screens.OrderHistory />}
          />
          <Route
            key='order-history'
            path={constants.routes.FORGOT_PASSWORD_SENT_EMAIL}
            element={<screens.ForgotPasswordSentEmail />}
          />
          <Route
            key='notifications'
            path={constants.routes.NOTIFICATIONS}
            element={<screens.Notifications />}
          />
          <Route
            key='faq'
            path={constants.routes.FAQ}
            element={<screens.FAQ />}
          />
          <Route
            key='wishlist'
            path={constants.routes.WISHLIST}
            element={<screens.Wishlist />}
          />
          <Route
            key='order'
            path={constants.routes.ORDER}
            element={<screens.Order />}
          />
        </Routes>
      </AnimatePresence>
      <components.BurgerContacts />
      <components.Toast />
    </QueryClientProvider>
  );
}

export default App;
