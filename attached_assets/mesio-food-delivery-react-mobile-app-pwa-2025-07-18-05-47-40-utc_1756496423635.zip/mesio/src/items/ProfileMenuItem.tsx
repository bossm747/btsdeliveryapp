import React from 'react';
import {Link} from 'react-router-dom';

import {constants} from '@/constants';

import RightArrowSvg from '@/assets/svg/right-arrow.svg?react';

type Props = {
  to: string;
  title: string;
  description?: string;
  icon: React.ReactNode;
};

export const ProfileMenuItem: React.FC<Props> = ({
  icon,
  description,
  title,
  to = '#',
}) => {
  return (
    <Link
      to={to}
      style={{
        ...constants.flex.FLEX_ROW,
        gap: 12,
        borderBottom: '1px solid #C8C8D3',
        borderBottomStyle: 'dashed',
        paddingBottom: 14,
      }}
    >
      {icon}
      <div style={{flex: 1}}>
        <h3
          style={{
            fontSize: 16,
            color: constants.colors.MAIN_DARK_COLOR,
            marginBottom: 2,
          }}
        >
          {title}
        </h3>
        {description && <p style={{fontSize: 12}}>{description}</p>}
      </div>
      <RightArrowSvg />
    </Link>
  );
};
