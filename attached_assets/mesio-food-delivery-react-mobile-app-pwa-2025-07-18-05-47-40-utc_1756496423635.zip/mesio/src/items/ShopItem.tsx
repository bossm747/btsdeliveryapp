import React from 'react';

import {hooks} from '@/hooks';
import {DishType} from '@/types';
import {stores} from '@/stores';
import {constants} from '@/constants';
import {components} from '@/components';

import AddToCartSvg from '@/assets/svg/add-to-cart.svg?react';
import WishlistAddSvg from '@/assets/svg/wishlist-add.svg?react';

type Props = {
  dish: DishType;
};

export const ShopItem: React.FC<Props> = ({dish}) => {
  const {navigate} = hooks.useRouter();
  const {addToCart} = stores.useCartStore();
  const {list: wishlist, addToWishlist} = stores.useWishlistStore();
  const isInWishlist = wishlist.some((item) => item.id === dish?.id);

  return (
    <li
      style={{
        ...constants.styles.boxShadow,
        borderRadius: 10,
        padding: 12,
        paddingTop: 3,
        position: 'relative',
      }}
    >
      <button
        onClick={() => {
          navigate(constants.routes.DISH, {state: {dishId: dish.id}});
        }}
      >
        <img
          src={dish.image}
          alt={dish.name}
          style={{width: '100%'}}
        />
      </button>
      <button
        style={{position: 'absolute', top: 0, right: 0, padding: 10}}
        onClick={(e) => {
          e.stopPropagation();
          e.preventDefault();
          addToCart(dish);
        }}
      >
        <AddToCartSvg />
      </button>
      <button
        style={{position: 'absolute', top: 0, left: 0, padding: 10}}
        onClick={(e) => {
          e.stopPropagation();
          e.preventDefault();
          addToWishlist(dish);
        }}
      >
        <WishlistAddSvg
          color={isInWishlist ? constants.colors.RED_COLOR : '#BDBDBD'}
        />
      </button>
      <h2
        style={{
          fontSize: 14,
          textAlign: 'center',
          color: constants.colors.MAIN_DARK_COLOR,
          marginBottom: 5,
          fontWeight: 500,
          marginLeft: 5,
          marginRight: 5,
          textTransform: 'capitalize',
        }}
        className='number-of-lines-1'
      >
        {dish.name}
      </h2>
      <p
        style={{fontSize: 14, textAlign: 'center', marginBottom: 14}}
        className='number-of-lines-1'
      >
        {dish.ingredients?.join(', ') || 'No ingredients'}
      </p>
      <span
        style={{
          textAlign: 'center',
          display: 'block',
          fontSize: 14,
          fontWeight: 600,
          color: '#FE724E',
          marginBottom: 10,
        }}
      >
        ${dish.price.toFixed(2)}
      </span>
      <components.AddToCart dish={dish} />
    </li>
  );
};
