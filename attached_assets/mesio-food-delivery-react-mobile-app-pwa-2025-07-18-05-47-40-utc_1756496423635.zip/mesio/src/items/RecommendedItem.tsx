import React from 'react';

import {hooks} from '@/hooks';
import {DishType} from '@/types';
import {constants} from '@/constants';
import {components} from '@/components';

type Props = {
  dish: DishType;
};

export const RecommendedItem: React.FC<Props> = ({dish}) => {
  const {navigate} = hooks.useRouter();

  return (
    <li
      style={{
        gap: 4,
        ...constants.flex.FLEX_ROW,
        ...constants.styles.boxShadow,
        borderRadius: 10,
        padding: 6,
        paddingTop: 0,
        paddingLeft: 0,
        paddingRight: 20,
        width: '100%',
      }}
    >
      <button
        onClick={() => {
          navigate(constants.routes.DISH, {state: {dishId: dish.id}});
        }}
      >
        <img
          src={dish.image}
          alt={dish.name}
          style={{width: 100, height: 'auto', borderRadius: 10}}
        />
      </button>

      <div style={{display: 'flex', flexDirection: 'column', flex: 1}}>
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 4,
            justifyContent: 'space-between',
          }}
        >
          <h2
            style={{
              fontSize: 14,
              color: constants.colors.MAIN_DARK_COLOR,
              fontWeight: 500,
              marginBottom: 6,
              textTransform: 'capitalize',
            }}
          >
            {dish.name}
          </h2>
          <span style={{fontSize: 12}}>
            {dish.weight} {dish.type === 'drink' ? 'ml' : 'g'}
          </span>
        </div>
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 4,
            marginBottom: 2,
          }}
        >
          <components.Rating rating={3} />
          <span style={{fontSize: 12}}>({dish.rating})</span>
        </div>
        <p
          style={{fontSize: 12, color: '#666', marginTop: 4}}
          className='number-of-lines-1'
        >
          {dish.ingredients?.join(', ') || 'No ingredients'}
        </p>
      </div>
    </li>
  );
};
