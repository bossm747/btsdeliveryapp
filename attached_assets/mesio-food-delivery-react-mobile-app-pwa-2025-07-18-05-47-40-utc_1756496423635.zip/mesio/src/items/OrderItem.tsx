import React from 'react';

import {hooks} from '@/hooks';
import {stores} from '@/stores';
import {DishType} from '@/types';
import {constants} from '@/constants';
import {components} from '@/components';

import PlusSvg from '@/assets/svg/plus.svg?react';
import MinusSvg from '@/assets/svg/minus.svg?react';

type Props = {
  dish: DishType;
};

export const OrderItem: React.FC<Props> = ({dish}) => {
  const {navigate} = hooks.useRouter();
  const {addToCart, removeFromCart, list: cart} = stores.useCartStore();
  const inCart = cart.find((item) => item.id === dish?.id);
  const quantity = inCart ? inCart.quantity : 0;
  return (
    <li
      style={{
        gap: 4,
        ...constants.flex.FLEX_ROW,
        ...constants.styles.boxShadow,
        borderRadius: 10,
        padding: 6,
        paddingTop: 0,
        paddingLeft: 0,
        paddingRight: 4,
        width: '100%',
      }}
    >
      <button
        onClick={() => {
          navigate(constants.routes.DISH, {state: {dishId: dish.id}});
        }}
      >
        <img
          src={dish.image}
          alt={dish.name}
          style={{width: 100, height: 'auto', borderRadius: 10}}
        />
      </button>

      <div style={{display: 'flex', flexDirection: 'column', flex: 1}}>
        <h2
          style={{
            fontSize: 14,
            color: constants.colors.MAIN_DARK_COLOR,
            fontWeight: 500,
            marginBottom: 6,
            textTransform: 'capitalize',
          }}
        >
          {dish.name}
        </h2>
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 4,
            marginBottom: 2,
          }}
        >
          <components.Rating rating={3} />
          <span style={{fontSize: 12}}>({dish.rating})</span>
        </div>
        <p
          style={{fontSize: 12, color: '#666', marginTop: 4}}
          className='number-of-lines-1'
        >
          {dish.ingredients?.join(', ') || 'No ingredients'}
        </p>
      </div>

      <div
        style={{
          display: 'flex',
          gap: 0,
          flexDirection: 'column',
          marginLeft: 20,
          alignItems: 'center',
        }}
      >
        <button
          style={{padding: 10}}
          onClick={() => removeFromCart(dish)}
        >
          <MinusSvg />
        </button>
        <span style={{fontSize: 10}}>{quantity}</span>
        <button
          style={{padding: 10}}
          onClick={() => addToCart(dish)}
        >
          <PlusSvg />
        </button>
      </div>
    </li>
  );
};
