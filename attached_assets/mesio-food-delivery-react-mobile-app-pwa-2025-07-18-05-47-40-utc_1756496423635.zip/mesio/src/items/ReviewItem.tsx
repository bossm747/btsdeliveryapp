import React from 'react';

import {hooks} from '@/hooks';
import {ReviewType} from '@/types';
import {constants} from '@/constants';
import {components} from '@/components';

type Props = {
  review: ReviewType;
};

export const ReviewItem: React.FC<Props> = ({review}) => {
  const {navigate} = hooks.useRouter();

  return (
    <li
      style={{
        backgroundColor: constants.colors.WHITE_COLOR,
        ...constants.styles.boxShadow,
        padding: 20,
        borderRadius: 10,
      }}
    >
      {/* top block */}
      <div
        style={{
          ...constants.flex.FLEX_ROW,
          marginBottom: 11,
          borderBottom: '1px solid #E0E0E0',
          paddingBottom: 11,
          gap: 14,
        }}
      >
        <img
          src={review.avatar}
          alt={review.name}
          style={{width: 30, height: 30, borderRadius: '50%'}}
        />
        <div style={{flex: 1}}>
          <div
            style={{
              flex: 1,
              ...constants.flex.FLEX_ROW_BETWEEN,
              marginBottom: 2,
            }}
          >
            <h5 style={{color: constants.colors.MAIN_DARK_COLOR, fontSize: 14}}>
              {review.name}
            </h5>
            <span style={{fontSize: 12}}>{review.date}</span>
          </div>
          <div style={{flex: 1, ...constants.flex.FLEX_ROW_BETWEEN}}>
            <components.Rating rating={review.rating} />
            <button
              onClick={() => {
                navigate(constants.routes.COMMENT_REPLY);
              }}
            >
              <span
                style={{fontSize: 10, color: constants.colors.SEA_GREEN_COLOR}}
              >
                Reply
              </span>
            </button>
          </div>
        </div>
      </div>
      {/* botttom block */}
      <p style={{fontSize: 14, lineHeight: 1.5}}>{review.comment}</p>
    </li>
  );
};
