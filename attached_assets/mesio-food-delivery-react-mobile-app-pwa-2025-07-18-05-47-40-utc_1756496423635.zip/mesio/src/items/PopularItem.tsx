import React from 'react';

import {hooks} from '@/hooks';
import {stores} from '@/stores';
import {DishType} from '@/types';
import {constants} from '@/constants';
import {components} from '@/components';

import WishlistAddSvg from '@/assets/svg/wishlist-add.svg?react';

type Props = {
  dish: DishType;
};

export const PopularItem: React.FC<Props> = ({dish}) => {
  const {navigate} = hooks.useRouter();
  const {
    list: wishlist,
    addToWishlist,
    removeFromWishlist,
  } = stores.useWishlistStore();
  const {addToCart, list: cart} = stores.useCartStore();
  const inCart = cart.find((item) => item.id === dish?.id);
  const isInWishlist = wishlist.some((item) => item.id === dish?.id);

  const {showToast} = stores.useToastStore();

  return (
    <div
      style={{
        borderRadius: 10,
        maxWidth: 155,
        width: '100%',
        padding: 12,
        paddingTop: 4,
        position: 'relative',
        ...constants.styles.boxShadow,
      }}
      onClick={() => {
        navigate(constants.routes.DISH, {
          state: {dishId: dish.id},
        });
      }}
    >
      <img
        src={dish.image}
        alt={dish.name}
        style={{width: '100%', height: 'auto', objectFit: 'contain'}}
      />
      <h2
        className='number-of-lines-1'
        style={{
          fontSize: 14,
          textAlign: 'center',
          color: constants.colors.MAIN_DARK_COLOR,
          marginBottom: 5,
          fontWeight: 500,
          marginLeft: 5,
          marginRight: 5,
          textTransform: 'capitalize',
        }}
      >
        {dish.name}
      </h2>
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 4,
          justifyContent: 'center',
          marginBottom: 11,
        }}
      >
        <components.Rating rating={dish.rating} />
        <span style={{fontSize: 12}}>{dish.rating}</span>
      </div>
      <span
        style={{
          fontSize: 14,
          fontWeight: 600,
          textAlign: 'center',
          margin: '0 auto',
          display: 'block',
          color: '#FE724E',
          marginBottom: 11,
        }}
      >
        ${dish.price?.toFixed(2) || '0'}
      </span>
      <components.AddToCart dish={dish} />
      <button
        style={{position: 'absolute', top: 0, right: 0, padding: 12}}
        onClick={(e) => {
          e.stopPropagation();
          e.preventDefault();
          const currentQuantity = inCart?.quantity ?? 0;
          addToCart(dish);
          showToast(`${dish.name} added to cart (${currentQuantity + 1})`);
        }}
      >
        <components.AddToCartIcon inCart={inCart ? true : false} />
      </button>
      <button
        style={{position: 'absolute', top: 0, left: 0, padding: 12}}
        onClick={(e) => {
          e.stopPropagation();
          e.preventDefault();
          if (isInWishlist) {
            removeFromWishlist(dish);
          } else {
            addToWishlist(dish);
          }
        }}
      >
        <WishlistAddSvg
          color={isInWishlist ? constants.colors.RED_COLOR : '#BDBDBD'}
        />
      </button>
    </div>
  );
};
