import React from 'react';

import {constants} from '@/constants';

type Props = {
  notification: any; // Replace 'any' with the actual type of your notification
};

export const NotificationItem: React.FC<Props> = ({notification}) => {
  return (
    <div
      style={{
        border: '1px solid #ECECEC',
        padding: '19px 15px',
        borderRadius: 10,
        ...constants.flex.FLEX_ROW,
        gap: 15,
      }}
    >
      <notification.icon width={40} />
      <div style={{...constants.flex.FLEX_COLUMN, flex: 1}}>
        <span
          style={{
            fontSize: 16,
            color: constants.colors.MAIN_DARK_COLOR,
            fontWeight: 'bold',
            marginBottom: 3,
          }}
          className='number-of-lines-1'
        >
          {notification.title}
        </span>
        <span
          className='number-of-lines-1'
          style={{fontSize: 14, color: constants.colors.TEXT_COLOR}}
        >
          {notification.message}
        </span>
      </div>
    </div>
  );
};
