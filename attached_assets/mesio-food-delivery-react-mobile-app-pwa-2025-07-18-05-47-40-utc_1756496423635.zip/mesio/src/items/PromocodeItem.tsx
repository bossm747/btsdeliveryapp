import React from 'react';

import CopySvg from '@/assets/svg/copy.svg?react';

import {stores} from '@/stores';
import {constants} from '@/constants';
import type {PromocodeType} from '@/types';

type Props = {promocode: PromocodeType};

export const PromocodeItem: React.FC<Props> = ({promocode}) => {
  const {showToast} = stores.useToastStore();

  const copyPromocode = (code: string) => {
    showToast(`Promocode ${code} copied to clipboard!`);
  };

  const renderContent = () => {
    return (
      <div
        style={{
          border: '1px solid #F1F1F1',
          padding: 15,
          borderRadius: 10,
          ...constants.flex.FLEX_ROW,
          gap: 15,
          cursor: 'pointer',
        }}
        onClick={() => copyPromocode(promocode.code)}
      >
        <img
          src={promocode.logo}
          alt={promocode.name}
          className='promocode-logo'
          style={{width: 55, height: 55}}
        />
        <div style={{...constants.flex.FLEX_COLUMN, flex: 1}}>
          <h2
            style={{
              fontSize: 16,
              color: constants.colors.MAIN_DARK_COLOR,
              fontWeight: 'bold',
              marginBottom: 3,
            }}
            className='number-of-lines-1'
          >
            {promocode.name}
          </h2>
          <span
            style={{
              fontSize: 14,
              fontWeight: 700,
              color: constants.colors.RED_COLOR,
              marginBottom: 3,
            }}
            className='number-of-lines-1'
          >
            {promocode.discount}% Off
          </span>
          <span
            className='number-of-lines-1'
            style={{fontSize: 14}}
          >
            Valid until {promocode.expiresAt}
          </span>
        </div>
        <CopySvg />
      </div>
    );
  };

  return renderContent();
};
