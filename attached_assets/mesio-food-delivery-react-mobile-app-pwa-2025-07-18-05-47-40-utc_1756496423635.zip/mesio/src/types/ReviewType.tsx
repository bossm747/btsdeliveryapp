export type ReviewType = {
  id: number;
  name: string;
  rating: number;
  date: string;
  avatar: string;
  comment: string;
};
