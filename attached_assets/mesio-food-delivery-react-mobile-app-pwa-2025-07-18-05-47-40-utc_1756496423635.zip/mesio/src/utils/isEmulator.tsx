'use client';

export const isEmulator = () => {
  if (typeof window === 'undefined') return false;

  const userAgent = window.navigator.userAgent.toLowerCase();
  const platform = window.navigator.platform?.toLowerCase() || '';

  const androidChecks = [
    userAgent.includes('android') && userAgent.includes('sdk'),
    userAgent.includes('emulator'),
    userAgent.includes('genymotion'),
    userAgent.includes('bluestacks'),
    userAgent.includes('noxplayer'),
    userAgent.includes('memu'),
    userAgent.includes('ldplayer'),
  ];

  const iOSChecks = [
    userAgent.includes('simulator'),
    platform.includes('iphonesimulator'),
    platform.includes('ipadsimulator'),
    userAgent.includes('iphone') && userAgent.includes('simulator'),
    userAgent.includes('ipad') && userAgent.includes('simulator'),
    userAgent.includes('version/') &&
      userAgent.includes('mobile/') &&
      platform.includes('mac'),
  ];

  const generalChecks = [
    !!(window as any).webdriver,
    !!(window.navigator as any).webdriver,
    !!(window as any).__webdriver_script_fn,
    userAgent.includes('headlesschrome'),
  ];

  return [...androidChecks, ...iOSChecks, ...generalChecks].some(Boolean);
};
