import {isBrowser} from './isBrowser';
import {isEmulator} from './isEmulator';
import {isMobileDevice} from './isMobileDevice';

export const utils = {
  isBrowser,
  isEmulator,
  isMobileDevice,
};
