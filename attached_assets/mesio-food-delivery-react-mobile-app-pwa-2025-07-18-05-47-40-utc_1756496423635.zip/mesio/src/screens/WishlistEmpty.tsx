import React from 'react';

import EmptyBag from '@/assets/svg/empty-bag.svg?react';

import {hooks} from '@/hooks';
import {constants} from '@/constants';
import {components} from '@/components';

export const WishlistEmpty: React.FC = () => {
  const {navigate} = hooks.useRouter();

  const renderBottomBar = () => {
    return <components.BottomTabBar />;
  };

  const renderContent = () => {
    return (
      <main
        style={{
          marginTop: constants.sizes.HEADER_HEIGHT,
          marginBottom: constants.sizes.TAB_BAR_HEIGHT,
          padding: '20px 20px 20px 20px',
          ...constants.flex.FLEX_COLUMN_CENTER,
          width: '100%',
          height: '100%',
        }}
      >
        <EmptyBag style={{marginBottom: 20}} />
        <h2
          style={{
            marginBottom: 11,
            fontSize: 20,
            fontWeight: 700,
            textTransform: 'capitalize',
            color: constants.colors.SEA_GREEN_COLOR,
          }}
        >
          Your Wishlist is empty
        </h2>
        <p
          style={{
            maxWidth: 234,
            textAlign: 'center',
            marginBottom: 26,
            lineHeight: 1.5,
          }}
        >
          Looks like you have not added any items to your wishlist yet.
        </p>
        <components.Button
          label='Shop now'
          onClick={() => navigate(constants.routes.SHOP)}
        />
      </main>
    );
  };

  return (
    <components.MotionWrapper>
      <components.SafeAreaView>
        {renderContent()}
        {renderBottomBar()}
      </components.SafeAreaView>
    </components.MotionWrapper>
  );
};
