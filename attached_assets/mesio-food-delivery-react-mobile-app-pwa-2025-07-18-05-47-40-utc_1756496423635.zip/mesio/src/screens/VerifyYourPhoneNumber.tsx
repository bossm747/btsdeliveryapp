import React from 'react';

import {hooks} from '@/hooks';
import {constants} from '@/constants';
import {components} from '@/components';

export const VerifyYourPhoneNumber: React.FC = () => {
  const {navigate} = hooks.useRouter();
  const {form, handleChangeField} = hooks.useFormField({phoneNumber: ''});

  const handleSignIn = () => {
    navigate(constants.routes.CONFIRMATION_CODE, {
      replace: true,
    });
  };

  const renderHeader = () => {
    return (
      <components.Header
        showGoBack={true}
        title='Verify Your Phone Number'
      />
    );
  };

  const renderContent = () => {
    return (
      <main
        style={{
          marginTop: constants.sizes.HEADER_HEIGHT,
          paddingLeft: 20,
          paddingRight: 20,
          paddingTop: '10%',
        }}
      >
        <h2
          style={{
            textAlign: 'center',
            ...constants.typography.h2,
            color: constants.colors.SEA_GREEN_COLOR,
            marginBottom: 10,
          }}
        >
          Verify
        </h2>
        <p
          style={{
            maxWidth: 250,
            textAlign: 'center',
            margin: '0 auto',
            marginBottom: 27,
          }}
        >
          We have sent you an SMS with a code to number +17 0123456789
        </p>
        <components.Input
          placeholder='+190 111 222 333'
          containerStyle={{marginBottom: 20}}
          value={form.phoneNumber}
          onClick={() => handleChangeField('phoneNumber', 'phone number')}
        />
        <components.Button
          label='Confirm'
          onClick={handleSignIn}
        />
      </main>
    );
  };

  return (
    <components.MotionWrapper>
      <components.SafeAreaView>
        {renderHeader()}
        {renderContent()}
      </components.SafeAreaView>
    </components.MotionWrapper>
  );
};
