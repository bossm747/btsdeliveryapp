import React from 'react';
import {Link} from 'react-router-dom';

import {hooks} from '@/hooks';
import {stores} from '@/stores';
import {constants} from '@/constants';
import {components} from '@/components';

export const EditProfile: React.FC = () => {
  const {navigate} = hooks.useRouter();
  const {showToast} = stores.useToastStore();
  const {form, handleChangeField} = hooks.useFormField({
    fullName: '',
    phone: '',
    dateOfBirth: '',
    gender: '',
    address: '',
  });

  const handleUpdateProfile = () => {
    if (
      !form.fullName ||
      !form.phone ||
      !form.dateOfBirth ||
      !form.gender ||
      !form.address
    ) {
      showToast('Please fill in all fields.');
      return;
    }

    if (!form.phone.match(/^\d{10}$/)) {
      showToast('Please enter a valid phone number.');
      return;
    }

    if (!form.dateOfBirth) {
      showToast('Please enter your date of birth.');
      return;
    }

    if (!form.gender) {
      showToast('Please select your gender.');
      return;
    }

    if (!form.address) {
      showToast('Please enter your address.');
      return;
    }

    navigate(constants.routes.PROFILE, {
      replace: true,
    });
  };

  const renderHeader = () => {
    return (
      <components.Header
        showGoBack={true}
        title='Edit Profile'
      />
    );
  };

  const renderContent = () => {
    const h3Styles: React.CSSProperties = {
      color: constants.colors.MAIN_DARK_COLOR,
      fontSize: 16,
      marginBottom: 8,
    };

    return (
      <main style={{marginTop: constants.sizes.HEADER_HEIGHT, padding: 20}}>
        <ul style={{...constants.flex.FLEX_COLUMN, gap: 18, marginBottom: 40}}>
          <li>
            <h3 style={h3Styles}>Full name</h3>
            <components.Input
              placeholder='Jhon Smith'
              value={form.fullName}
              onClick={() => handleChangeField('fullName', 'Full Name')}
            />
          </li>
          <li>
            <h3 style={h3Styles}>Telephone number</h3>
            <components.Input
              placeholder='0123 456 789'
              value={form.phone}
              onClick={() => handleChangeField('phone', 'Phone Number')}
            />
          </li>
          <li>
            <h3 style={h3Styles}>Date of birth</h3>
            <components.Input
              placeholder='Enter date of birth'
              value={form.dateOfBirth}
              onClick={() => handleChangeField('dateOfBirth', 'Date of Birth')}
            />
          </li>
          <li>
            <h3 style={h3Styles}>Gender</h3>
            <components.Input
              placeholder='Enter gender'
              value={form.gender}
              onClick={() => handleChangeField('gender', 'Gender')}
            />
          </li>
          <li>
            <h3 style={h3Styles}>Address</h3>
            <components.Input
              placeholder='Enter Address'
              value={form.address}
              onClick={() => handleChangeField('address', 'Address')}
            />
          </li>
        </ul>
        <components.Button
          label='Update Now'
          onClick={handleUpdateProfile}
        />
        <Link
          to={constants.routes.CHANGE_PASSWORD}
          style={{
            width: '100%',
            marginTop: 20,
            ...constants.flex.FLEX_ROW_CENTER,
            color: constants.colors.SEA_GREEN_COLOR,
          }}
        >
          Change Password
        </Link>
      </main>
    );
  };

  return (
    <components.MotionWrapper>
      <components.SafeAreaView>
        {renderHeader()}
        {renderContent()}
      </components.SafeAreaView>
    </components.MotionWrapper>
  );
};
