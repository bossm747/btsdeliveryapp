import React, {useState} from 'react';
import {Swiper, SwiperSlide} from 'swiper/react';

import {hooks} from '@/hooks';
import {constants} from '@/constants';
import {components} from '@/components';

export const Onboarding: React.FC = () => {
  const {navigate} = hooks.useRouter();
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);

  const renderCarousel = () => {
    return (
      <section
        style={{
          width: '100%',
          height: '100%',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
        }}
      >
        <Swiper
          onSlideChange={(swiper) => setCurrentSlideIndex(swiper.activeIndex)}
        >
          {constants.data.onboarding.map((item: any) => (
            <SwiperSlide
              key={item.id}
              style={{width: '100%', height: 'auto'}}
            >
              <img
                src={item.image}
                alt='Onboarding'
                style={{
                  width: '80%',
                  height: 'auto',
                  margin: '0 auto',
                }}
              />
            </SwiperSlide>
          ))}
        </Swiper>
      </section>
    );
  };

  const renderDetails = () => {
    const currentItem = constants.data.onboarding[currentSlideIndex];

    return (
      <section
        className='container'
        style={{
          paddingLeft: 20,
          paddingRight: 20,
          paddingBottom: 20,
          paddingTop: 48,
          borderTopLeftRadius: 30,
          borderTopRightRadius: 30,
          backgroundColor: constants.colors.SEA_GREEN_COLOR,
        }}
      >
        <h1
          style={{
            textAlign: 'center',
            textTransform: 'capitalize',
            fontSize: 30,
            fontWeight: 700,
            marginBottom: 20,
            color: constants.colors.WHITE_COLOR,
          }}
        >
          {currentItem.title}
        </h1>
        <p
          style={{
            textAlign: 'center',
            color: constants.colors.WHITE_COLOR,
            marginBottom: 40,
            paddingLeft: 20,
            paddingRight: 20,
            maxWidth: 320,
            marginLeft: 'auto',
            marginRight: 'auto',
          }}
        >
          {currentItem.description}
        </p>
        <section
          className='container'
          style={{
            gap: 10,
            marginBottom: 20,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          {constants.data.onboarding.map((item: any, index: number) => (
            <div
              key={item.id}
              style={{
                width: 12,
                height: 12,
                borderRadius: '6px',
                backgroundColor:
                  currentSlideIndex === index
                    ? constants.colors.ORANGE_COLOR
                    : constants.colors.WHITE_COLOR,
              }}
            />
          ))}
        </section>
        <components.Button
          label='Get Started'
          containerStyle={{backgroundColor: constants.colors.ORANGE_COLOR}}
          onClick={() => {
            navigate(constants.routes.SIGN_IN);
          }}
        />
      </section>
    );
  };

  const renderSafeAreaInsetBottom = () => {
    return (
      <components.SafeAreaInsetBottom
        backgroundColor={constants.colors.SEA_GREEN_COLOR}
      />
    );
  };

  return (
    <components.MotionWrapper>
      <components.SafeAreaView>
        {renderCarousel()}
        {renderDetails()}
        {renderSafeAreaInsetBottom()}
      </components.SafeAreaView>
    </components.MotionWrapper>
  );
};
