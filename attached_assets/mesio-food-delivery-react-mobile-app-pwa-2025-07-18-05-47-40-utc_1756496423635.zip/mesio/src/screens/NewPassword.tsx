import React from 'react';

import {hooks} from '@/hooks';
import {constants} from '@/constants';
import {components} from '@/components';

export const NewPassword: React.FC = () => {
  const {navigate} = hooks.useRouter();

  const {form, handleChangeField} = hooks.useFormField({
    newPassword: '',
  });

  const renderHeader = () => {
    return (
      <components.Header
        showGoBack={true}
        title='Reset Password'
      />
    );
  };

  const renderContent = () => {
    return (
      <main
        style={{
          marginTop: constants.sizes.HEADER_HEIGHT,
          padding: 20,
          width: '100%',
        }}
      >
        <p
          style={{
            marginBottom: 25,
            maxWidth: 302,
            textAlign: 'center',
            lineHeight: 1.5,
            marginLeft: 'auto',
            marginRight: 'auto',
          }}
        >
          Please enter your new password.
        </p>
        <components.Input
          placeholder='New Password'
          value={form.newPassword}
          onClick={() => handleChangeField('newPassword', 'New Password')}
          containerStyle={{marginBottom: 20}}
        />
        <components.Button
          label='Reset Password'
          onClick={() => {
            navigate(constants.routes.FORGOT_PASSWORD_SENT_EMAIL);
          }}
        />
      </main>
    );
  };

  return (
    <components.MotionWrapper>
      <components.SafeAreaView>
        {renderHeader()}
        {renderContent()}
      </components.SafeAreaView>
    </components.MotionWrapper>
  );
};
