import React from 'react';

import GiftSvg from '@/assets/svg/gift.svg?react';

import {hooks} from '@/hooks';
import {constants} from '@/constants';
import {components} from '@/components';

export const MyPromocodesEmpty: React.FC = () => {
  const {navigate} = hooks.useRouter();
  const {form, handleChangeField} = hooks.useFormField({voucher: ''});

  const handleSubmit = () => {
    navigate(constants.routes.MY_PROMOCODES, {
      replace: true,
    });
  };

  const renderHeader = () => {
    return (
      <components.Header
        showGoBack={true}
        title='My Promocodes Empty'
      />
    );
  };

  const renderContent = () => {
    return (
      <main
        style={{
          paddingLeft: 20,
          paddingRight: 20,
          paddingBottom: '30%',
          paddingTop: 20,
          marginTop: constants.sizes.HEADER_HEIGHT,
          ...constants.flex.FLEX_COLUMN_CENTER,
          height: '100%',
          width: '100%',
        }}
      >
        <GiftSvg style={{marginBottom: 34}} />
        <h2
          style={{
            fontSize: 22,
            fontWeight: 700,
            color: constants.colors.SEA_GREEN_COLOR,
            marginBottom: 10,
            textAlign: 'center',
            textTransform: 'capitalize',
            maxWidth: 300,
          }}
        >
          You do not have Promocodes
        </h2>
        <p style={{textAlign: 'center', marginBottom: 24, lineHeight: 1.5}}>
          Go hunt for vouchers at Foodsss <br />
          Voucher right away.
        </p>
        <components.Input
          placeholder='Enter the voucher'
          containerStyle={{marginBottom: 15}}
          value={form.voucher}
          onClick={() => handleChangeField('voucher', 'voucher')}
        />
        <components.Button
          label='Submit'
          onClick={handleSubmit}
        />
      </main>
    );
  };

  return (
    <components.MotionWrapper>
      <components.SafeAreaView>
        {renderHeader()}
        {renderContent()}
      </components.SafeAreaView>
    </components.MotionWrapper>
  );
};
