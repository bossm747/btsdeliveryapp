import React, {useMemo} from 'react';

import {hooks} from '@/hooks';
import {items} from '@/items';
import {DishType} from '@/types';
import {constants} from '@/constants';
import {components} from '@/components';

export const ShopCategory: React.FC = () => {
  const {location} = hooks.useRouter();
  const {data, isLoading, error} = hooks.useGetDishes();
  const {category} = location.state || {category: 'all'};

  const dishes = data && data.length > 0 ? data : [];

  const filtered = useMemo(() => {
    return dishes.filter(
      (dish: DishType) =>
        dish.category?.toLowerCase() === category.toLowerCase(),
    );
  }, [dishes, category]);

  if (isLoading) return <components.Loader />;
  if (error) return <components.Error />;

  const capitalizeWords = (str: string) => {
    if (!str) return 'Shop';

    return str
      .split(' ')
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
      .join(' ');
  };

  const renderHeader = () => {
    return (
      <components.Header
        showGoBack={true}
        title={capitalizeWords(category)}
      />
    );
  };

  const renderDishes = () => {
    if (!filtered || filtered.length === 0) {
      return null;
    }
    return (
      <main
        style={{
          marginTop: constants.sizes.HEADER_HEIGHT,
          padding: '18px 20px 20px 20px',
          overflowY: 'auto',
        }}
      >
        <ul
          style={{
            display: 'grid',
            gridTemplateColumns: '1fr 1fr',
            gap: 15,
          }}
        >
          {filtered.map((dish: DishType) => {
            return (
              <items.ShopItem
                key={dish.id}
                dish={dish}
              />
            );
          })}
        </ul>
      </main>
    );
  };

  return (
    <components.MotionWrapper>
      <components.SafeAreaView>
        {renderHeader()}
        {renderDishes()}
      </components.SafeAreaView>
    </components.MotionWrapper>
  );
};
