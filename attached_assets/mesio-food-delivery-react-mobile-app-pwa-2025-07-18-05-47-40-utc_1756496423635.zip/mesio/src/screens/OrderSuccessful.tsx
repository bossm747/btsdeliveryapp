import React, {useEffect} from 'react';

import SuccessSvg from '@/assets/svg/success.svg?react';

import {hooks} from '@/hooks';
import {stores} from '@/stores';
import {constants} from '@/constants';
import {components} from '@/components';

export const OrderSuccessful: React.FC = () => {
  const {navigate} = hooks.useRouter();
  const {resetCart} = stores.useCartStore();

  useEffect(() => {
    resetCart();
  }, []);

  const renderContent = () => {
    return (
      <main
        style={{
          padding: 20,
          ...constants.flex.FLEX_COLUMN,
          justifyContent: 'center',
          height: '100%',
          width: '100%',
        }}
      >
        <SuccessSvg
          style={{
            marginLeft: 'auto',
            marginRight: 'auto',
            marginBottom: 36,
          }}
        />
        <h2
          style={{
            ...constants.typography.h2,
            textTransform: 'capitalize',
            marginBottom: 10,
            marginLeft: 'auto',
            marginRight: 'auto',
            color: constants.colors.SEA_GREEN_COLOR,
          }}
        >
          Order successful!
        </h2>
        <p
          style={{
            maxWidth: 274,
            textAlign: 'center',
            fontSize: 16,
            marginLeft: 'auto',
            marginRight: 'auto',
            marginBottom: 20,
          }}
        >
          Your order will be delivered on time. <br />
          Thank you!
        </p>
        <components.Button
          label='View orders'
          containerStyle={{marginBottom: 15}}
          onClick={() => {
            navigate(constants.routes.ORDER_HISTORY);
          }}
        />
        <components.Button
          label='Continue Shopping'
          colorScheme='secondary'
          onClick={() => {
            navigate(constants.routes.HOME, {
              replace: true,
            });
          }}
        />
      </main>
    );
  };

  return (
    <components.MotionWrapper>
      <components.SafeAreaView>{renderContent()}</components.SafeAreaView>
    </components.MotionWrapper>
  );
};
