'use client';

import React, {useState} from 'react';

import CommentSvg from '@/assets/svg/comment.svg?react';

import {hooks} from '@/hooks';
import {constants} from '@/constants';
import {components} from '@/components';

export const LeaveAReview: React.FC = () => {
  const {navigate} = hooks.useRouter();

  const [rating, setRating] = useState<number>(0);

  const {form, handleChangeField} = hooks.useFormField({comment: ''});

  const handleConfirm = () => {
    navigate(-1);
  };

  const renderHeader = () => {
    return (
      <components.Header
        showGoBack={true}
        title='Leave a review'
      />
    );
  };

  const renderContent = () => {
    return (
      <main
        style={{
          marginTop: constants.sizes.HEADER_HEIGHT,
          height: '100%',
          width: '100%',
          paddingLeft: 20,
          paddingRight: 20,
          ...constants.flex.FLEX_COLUMN_CENTER,
        }}
      >
        <section style={{width: '100%'}}>
          <div
            style={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              marginBottom: 20,
            }}
          >
            <CommentSvg />
          </div>

          <p
            className='t16'
            style={{textAlign: 'center', marginBottom: 20}}
          >
            Your comments and suggestions help <br /> us improve the service
            quality better!
          </p>
          <components.RatingStars
            rating={rating}
            setRating={setRating}
            containerStyle={{marginBottom: 20}}
          />
          <button
            style={{
              marginBottom: 20,
              borderRadius: 10,
              width: '100%',
              backgroundColor: constants.colors.LIGHT_GRAY_COLOR,
            }}
            value={form.comment}
            onClick={() => handleChangeField('comment', 'comment')}
          >
            <p
              style={{
                height: 127,
                width: '100%',
                padding: 14,
                border: 'none',
                fontSize: 16,
                color: '#748BA0',
                backgroundColor: 'transparent',
                resize: 'none',
              }}
            >
              {form.comment || 'Write your review here...'}
            </p>
          </button>
          <components.Button
            label='Send review'
            onClick={() => {
              handleConfirm();
            }}
          />
        </section>
      </main>
    );
  };

  return (
    <components.MotionWrapper>
      <components.SafeAreaView>
        {renderHeader()}
        {renderContent()}
      </components.SafeAreaView>
    </components.MotionWrapper>
  );
};
