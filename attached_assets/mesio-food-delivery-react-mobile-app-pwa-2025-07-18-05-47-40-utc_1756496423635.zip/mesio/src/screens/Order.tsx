import React, {useEffect} from 'react';

import {items} from '@/items';
import {hooks} from '@/hooks';
import {stores} from '@/stores';
import {DishType} from '@/types';
import {constants} from '@/constants';
import {components} from '@/components';

export const Order: React.FC = () => {
  const {navigate} = hooks.useRouter();
  const {list: cart, total} = stores.useCartStore();

  useEffect(() => {
    if (cart.length === 0) {
      navigate(constants.routes.CART_EMPTY, {
        replace: true,
      });
    }
  }, [cart]);

  const renderHeader = () => {
    return (
      <components.Header
        title='Order'
        showGoBack={true}
        showBasket={true}
      />
    );
  };

  const renderBottomBar = () => {
    return <components.BottomTabBar />;
  };

  const renderContent = () => {
    return (
      <main
        style={{
          marginBottom: constants.sizes.TAB_BAR_HEIGHT,
          marginTop: constants.sizes.HEADER_HEIGHT,
          paddingLeft: 20,
          paddingRight: 20,
          paddingBottom: 20,
          paddingTop: 18,
          overflowY: 'auto',
        }}
      >
        <ul style={{...constants.flex.FLEX_COLUMN, gap: 14, marginBottom: 30}}>
          {cart.map((dish: DishType, index) => {
            return (
              <items.OrderItem
                dish={dish}
                key={index}
              />
            );
          })}
        </ul>
        <div style={{...constants.flex.FLEX_ROW, gap: 6, marginBottom: 20}}>
          <span
            style={{
              fontSize: 16,
              fontWeight: 700,
              color: constants.colors.MAIN_DARK_COLOR,
            }}
          >
            Total: ({cart.length}) items:
          </span>
          <span
            style={{
              fontSize: 16,
              fontWeight: 700,
              color: '#E94F08',
            }}
          >
            ${total.toFixed(2)}
          </span>
        </div>
        <components.Button
          label='Process to Checkout'
          onClick={() => navigate(constants.routes.CHECKOUT)}
        />
      </main>
    );
  };

  return (
    <components.MotionWrapper>
      <components.SafeAreaView>
        {renderHeader()}
        {renderContent()}
        {renderBottomBar()}
      </components.SafeAreaView>
    </components.MotionWrapper>
  );
};
