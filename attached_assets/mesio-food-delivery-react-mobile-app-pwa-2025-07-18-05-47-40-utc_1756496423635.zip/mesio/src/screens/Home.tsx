import React from 'react';
import 'swiper/swiper-bundle.css';
import {Swiper, SwiperSlide} from 'swiper/react';

import {hooks} from '@/hooks';
import {items} from '@/items';
import {DishType} from '@/types';
import {constants} from '@/constants';
import {components} from '@/components';

export const Home: React.FC = () => {
  const {navigate} = hooks.useRouter();
  const {data, isLoading} = hooks.useGetDishes();

  if (isLoading) return <components.Loader />;

  const categories = data
    ? Array.from(new Set(data.map((dish: DishType) => dish.category)))
    : [];

  const renderHeader = () => {
    return (
      <components.Header
        showBasket={true}
        showBurger={true}
        title='MESIO'
        titleStyle={{fontWeight: 500}}
      />
    );
  };

  const renderCategories = () => {
    return (
      <div style={{marginBottom: 30}}>
        <Swiper
          spaceBetween={10}
          slidesPerView={'auto'}
          pagination={{clickable: true}}
          mousewheel={true}
          style={{
            paddingLeft: 20,
            paddingRight: 20,
            paddingTop: 18,
          }}
        >
          {categories?.map((category: any) => {
            return (
              <SwiperSlide
                key={category.id}
                style={{width: 'auto'}}
              >
                <button
                  style={{
                    border: '1px solid #E0E0E0',
                    borderRadius: 10,
                    padding: 10,
                    userSelect: 'none',
                  }}
                  onClick={(e) => {
                    e.stopPropagation();
                    navigate(constants.routes.SHOP_CATEGORY, {
                      state: {category: category.toLowerCase()},
                    });
                  }}
                >
                  <span
                    style={{
                      fontSize: 14,
                      color: constants.colors.TEXT_COLOR,
                    }}
                  >
                    {category}
                  </span>
                </button>
              </SwiperSlide>
            );
          })}
        </Swiper>
      </div>
    );
  };

  const renderPopular = () => {
    return (
      <section style={{marginBottom: 30}}>
        <components.BlockHeading
          title='Popular Dishes'
          onClick={() => {
            navigate(constants.routes.SHOP, {
              state: {category: 'popular'},
            });
          }}
        />
        <Swiper
          spaceBetween={14}
          slidesPerView={'auto'}
          pagination={{clickable: true}}
          mousewheel={true}
          style={{
            paddingLeft: 20,
            paddingRight: 20,
            paddingBottom: 20,
            paddingTop: 18,
          }}
        >
          {data
            ?.filter((dish: DishType) => dish.isPopular)
            .map((dish: DishType) => {
              return (
                <SwiperSlide
                  key={dish.id}
                  style={{width: 'auto'}}
                >
                  <items.PopularItem
                    dish={dish}
                    key={dish.id}
                  />
                </SwiperSlide>
              );
            })}
        </Swiper>
      </section>
    );
  };

  const renderRecomended = () => {
    return (
      <section>
        <components.BlockHeading
          title='Recommended Dishes'
          onClick={() => {
            navigate(constants.routes.SHOP, {
              state: {category: 'recommended'},
            });
          }}
        />
        <ul
          style={{
            ...constants.flex.FLEX_COLUMN,
            paddingLeft: 20,
            paddingRight: 20,
            paddingTop: 18,
            gap: 14,
          }}
        >
          {data
            ?.filter((dish: DishType) => dish.isRecommended)
            .map((dish: DishType) => {
              return (
                <items.RecommendedItem
                  dish={dish}
                  key={dish.id}
                />
              );
            })}
        </ul>
      </section>
    );
  };

  const renderContent = () => {
    return (
      <main
        style={{
          overflowY: 'auto',
          marginTop: constants.sizes.HEADER_HEIGHT,
          marginBottom: constants.sizes.TAB_BAR_HEIGHT,
          paddingBottom: 20,
        }}
      >
        {renderCategories()}
        {renderPopular()}
        {renderRecomended()}
      </main>
    );
  };

  const renderBottomBar = () => {
    return <components.BottomTabBar />;
  };

  return (
    <components.MotionWrapper>
      <components.SafeAreaView>
        {renderHeader()}
        {renderContent()}
        {renderBottomBar()}
      </components.SafeAreaView>
    </components.MotionWrapper>
  );
};
