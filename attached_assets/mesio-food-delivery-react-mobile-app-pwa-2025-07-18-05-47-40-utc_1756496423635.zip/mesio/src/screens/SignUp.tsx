import {Link} from 'react-router-dom';
import React, {useEffect, useRef, useState} from 'react';

import {hooks} from '@/hooks';
import {constants} from '@/constants';
import {components} from '@/components';

export const SignUp: React.FC = () => {
  const {navigate} = hooks.useRouter();
  const footerRef = useRef<HTMLElement>(null);

  const [footerHeight, setFooterHeight] = useState(0);
  const [agreeToTerms, setAgreeToTerms] = useState(false);
  const [form, setForm] = useState({
    fullName: '',
    phoneNumber: '',
    email: '',
    password: '',
    confirmPassword: '',
  });

  useEffect(() => {
    if (footerRef.current) {
      setFooterHeight(footerRef.current.offsetHeight);
    }
  }, []);

  const handleChangeField = (field: keyof typeof form, label: string) => {
    const result = window.prompt(`Enter your ${label}`, form[field]);
    if (result !== null) {
      setForm((prev) => ({...prev, [field]: result}));
    }
  };

  const renderHeader = () => {
    return (
      <components.Header
        title='Sign Up'
        showGoBack={true}
      />
    );
  };

  const renderContent = () => {
    return (
      <main
        style={{
          marginTop: constants.sizes.HEADER_HEIGHT,
          marginBottom: footerHeight,
          paddingTop: '10%',
          paddingLeft: 20,
          paddingRight: 20,
          height: '100%',
          width: '100%',
        }}
      >
        <h2
          style={{
            textAlign: 'center',
            ...constants.typography.h2,
            textTransform: 'capitalize',
            marginBottom: 10,
            color: constants.colors.SEA_GREEN_COLOR,
          }}
        >
          Welcome to MESIO
        </h2>
        <p
          style={{
            textAlign: 'center',
            fontSize: 16,
            marginBottom: 28,
            color: constants.colors.TEXT_COLOR,
          }}
        >
          Sign up to continue
        </p>
        <components.Input
          containerStyle={{marginBottom: 15}}
          placeholder='Full Name'
          value={form.email}
          onClick={() => handleChangeField('email', 'email')}
          isValid={form.email.length > 0 && form.email.includes('@')}
        />
        <components.Input
          containerStyle={{marginBottom: 15}}
          placeholder='Phone Number'
          value={form.phoneNumber}
          onClick={() => handleChangeField('phoneNumber', 'phone number')}
        />
        <components.Input
          containerStyle={{marginBottom: 15}}
          placeholder='Email'
          value={form.email}
          onClick={() => handleChangeField('email', 'email')}
        />
        <components.Input
          containerStyle={{marginBottom: 15}}
          placeholder='Password'
          value={form.password}
          onClick={() => handleChangeField('password', 'password')}
        />
        <components.Input
          containerStyle={{marginBottom: 15}}
          placeholder='Confirm Password'
          value={form.confirmPassword}
          onClick={() =>
            handleChangeField('confirmPassword', 'confirm password')
          }
        />
        <div
          onClick={() => setAgreeToTerms(!agreeToTerms)}
          style={{
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: 10,
            marginBottom: 20,
          }}
        >
          <components.Checkbox checked={agreeToTerms} />
          <span style={{color: constants.colors.TEXT_COLOR}}>
            You agree to our Terms of Service
          </span>
        </div>

        <components.Button
          label='Sign Up'
          onClick={() => {
            navigate(constants.routes.VERIFY_YOUR_PHONE_NUMBER);
          }}
        />
      </main>
    );
  };

  const renderFooter = () => {
    return (
      <section
        ref={footerRef}
        style={{padding: 20, ...constants.flex.FLEX_ROW_CENTER, gap: 6}}
      >
        <span style={{color: constants.colors.MAIN_DARK_COLOR}}>
          Already have an account?
        </span>
        <Link
          to={constants.routes.SIGN_IN}
          style={{color: constants.colors.SEA_GREEN_COLOR, fontWeight: 500}}
        >
          Sing in!
        </Link>
      </section>
    );
  };

  return (
    <components.MotionWrapper>
      <components.SafeAreaView>
        {renderHeader()}
        {renderContent()}
        {renderFooter()}
      </components.SafeAreaView>
    </components.MotionWrapper>
  );
};
