import React, {useMemo, useState, useRef} from 'react';

import {hooks} from '@/hooks';
import {items} from '@/items';
import {DishType} from '@/types';
import {constants} from '@/constants';
import {components} from '@/components';

export const Shop: React.FC = () => {
  const {location} = hooks.useRouter();
  const {category} = location.state || {category: 'all'};
  const [searchQuery, setSearchQuery] = useState('');
  const searchInputRef = useRef<HTMLButtonElement>(null);
  const {data, isLoading, error} = hooks.useGetDishes();

  const marginTop = constants.sizes.HEADER_HEIGHT + 50 + 10;

  const filteredDishes = useMemo(() => {
    if (!data) return [];

    let filtered = data;

    if (category === 'popular') {
      filtered = data.filter((dish: DishType) => dish.isPopular);
    } else if (category === 'recommended') {
      filtered = data.filter((dish: DishType) => dish.isRecommended);
    } else if (category === 'all' || !category) {
      filtered = data;
    } else {
      filtered = data.filter(
        (dish: DishType) =>
          dish.category?.toLowerCase() === category.toLowerCase(),
      );
    }

    if (searchQuery.trim()) {
      return filtered.filter(
        (dish: DishType) =>
          dish.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          dish.description?.toLowerCase().includes(searchQuery.toLowerCase()),
      );
    }

    return filtered;
  }, [data, searchQuery]);

  if (error) return <components.Error />;
  if (isLoading) return <components.Loader />;

  const renderHeader = () => {
    return (
      <components.Header
        showGoBack={true}
        title={
          category === 'all'
            ? 'Shop'
            : category.charAt(0).toUpperCase() + category.slice(1)
        }
        showBasket={true}
      />
    );
  };

  const renderSearch = () => {
    return (
      <button
        ref={searchInputRef}
        style={{
          backgroundColor: constants.colors.LIGHT_GRAY_COLOR,
          width: '100%',
          borderRadius: 10,
          display: 'flex',
          alignItems: 'center',
          height: 50,
          paddingLeft: 20,
          border: '1px solid #EEEEEE',
          cursor: 'pointer',
          position: 'fixed',
          top: constants.sizes.HEADER_HEIGHT + 10,
          zIndex: 10000,
          maxWidth: 'calc(100% - 40px)',
          left: '50%',
          transform: 'translateX(-50%)',
        }}
        onClick={(e) => {
          e.stopPropagation();
          e.preventDefault();
          const result = window.prompt('Enter your search query', searchQuery);
          if (result !== null) {
            setSearchQuery(result);
          }
        }}
        type='button'
      >
        <span
          style={{
            fontSize: 14,
            lineHeight: 1.5,
            marginRight: 'auto',
            paddingRight: 20,
            color: searchQuery
              ? constants.colors.MAIN_DARK_COLOR
              : constants.colors.TEXT_COLOR,
          }}
        >
          {searchQuery || 'Search dishes...'}
        </span>
        {/* clear text */}
        {searchQuery && (
          <button
            style={{
              position: 'absolute',
              right: 20,
              cursor: 'pointer',
            }}
            onClick={(e) => {
              e.stopPropagation();
              e.preventDefault();
              setSearchQuery('');
            }}
          >
            <span>clear</span>
          </button>
        )}
      </button>
    );
  };

  const renderDishes = () => {
    if (!filteredDishes || filteredDishes.length === 0) {
      return null;
    }
    return (
      <main
        style={{
          padding: 20,
          marginTop: marginTop,
          overflowY: 'auto',
          height: '100%',
          zIndex: 1,
        }}
      >
        <ul
          style={{
            display: 'grid',
            gridTemplateColumns: '1fr 1fr',
            gap: 15,
          }}
        >
          {filteredDishes.map((dish: DishType) => {
            return (
              <items.ShopItem
                key={dish.id}
                dish={dish}
              />
            );
          })}
        </ul>
      </main>
    );
  };

  const renderIfEmpty = () => {
    if (filteredDishes.length > 0 || !searchQuery.trim()) {
      return null;
    }
    return (
      <main style={{marginTop: marginTop, width: '100%', height: '100%'}}>
        {filteredDishes.length === 0 && searchQuery.trim() && (
          <div
            style={{
              textAlign: 'center',
              height: '100%',
              ...constants.flex.FLEX_COLUMN_CENTER,
            }}
          >
            <span style={{fontSize: 16, color: '#666'}}>
              No dishes found for &quot;{searchQuery}&quot;
            </span>
          </div>
        )}
      </main>
    );
  };

  return (
    <components.MotionWrapper>
      <components.SafeAreaView>
        {renderHeader()}
        {renderSearch()}
        {renderDishes()}
        {renderIfEmpty()}
      </components.SafeAreaView>
    </components.MotionWrapper>
  );
};
