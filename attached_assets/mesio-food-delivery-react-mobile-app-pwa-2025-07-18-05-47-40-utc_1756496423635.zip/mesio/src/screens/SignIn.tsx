import {Link} from 'react-router-dom';
import React, {useEffect, useRef, useState} from 'react';

import {hooks} from '@/hooks';
import {constants} from '@/constants';
import {components} from '@/components';

export const SignIn: React.FC = () => {
  const {navigate} = hooks.useRouter();
  const footerRef = useRef<HTMLElement>(null);

  const [footerHeight, setFooterHeight] = useState(0);
  const [rememberMe, setRememberMe] = useState(false);
  const {form, handleChangeField} = hooks.useFormField({
    email: '',
    password: '',
  });

  const handleSignIn = () => {
    navigate(constants.routes.HOME, {
      replace: true,
    });
  };

  useEffect(() => {
    if (footerRef.current) {
      setFooterHeight(footerRef.current.offsetHeight);
    }
  }, []);

  const renderHeader = () => {
    return (
      <components.Header
        title='Sign In'
        showGoBack={true}
      />
    );
  };

  const renderContent = () => {
    return (
      <main
        style={{
          marginTop: constants.sizes.HEADER_HEIGHT,
          marginBottom: footerHeight,
          paddingLeft: 20,
          paddingRight: 20,
          height: '100%',
          width: '100%',
          ...constants.flex.FLEX_COLUMN_CENTER,
          paddingBottom: '20%',
          overflowY: 'auto',
        }}
      >
        <h2
          style={{
            textAlign: 'center',
            ...constants.typography.h2,
            textTransform: 'capitalize',
            marginBottom: 10,
            color: constants.colors.SEA_GREEN_COLOR,
          }}
        >
          Welcome Back Jhon!
        </h2>
        <p
          style={{
            textAlign: 'center',
            fontSize: 16,
            marginBottom: 28,
            color: constants.colors.TEXT_COLOR,
          }}
        >
          Sign in to continue
        </p>
        <components.Input
          containerStyle={{marginBottom: 15}}
          placeholder='johndoe@mail.com'
          value={form.email}
          onClick={() => handleChangeField('email', 'email')}
          isValid={form.email.length > 0 && form.email.includes('@')}
        />
        <components.Input
          containerStyle={{marginBottom: 15}}
          placeholder='**********'
          value={form.password}
          onClick={() => handleChangeField('password', 'password')}
          isValid={form.password.length > 0 && form.password.length >= 6}
        />
        <div
          style={{
            ...constants.flex.FLEX_ROW_BETWEEN,
            marginBottom: 18,
            width: '100%',
          }}
        >
          <div
            style={{...constants.flex.FLEX_ROW_CENTER, gap: 10}}
            onClick={() => setRememberMe(!rememberMe)}
          >
            <components.Checkbox checked={rememberMe} />
            <span>Remember me</span>
          </div>
          <Link
            to={constants.routes.FORGOT_PASSWORD}
            style={{color: '#FE724E'}}
          >
            Forgot password ?
          </Link>
        </div>
        <components.Button
          label='Sign in'
          onClick={() => handleSignIn()}
        />
      </main>
    );
  };

  const renderFooter = () => {
    return (
      <section
        ref={footerRef}
        style={{padding: 20, ...constants.flex.FLEX_ROW_CENTER, gap: 6}}
      >
        <span style={{color: constants.colors.MAIN_DARK_COLOR}}>
          {`Don't have an account?`}
        </span>
        <Link
          to={constants.routes.SIGN_UP}
          style={{color: constants.colors.SEA_GREEN_COLOR, fontWeight: 500}}
        >
          Sing up!
        </Link>
      </section>
    );
  };

  return (
    <components.MotionWrapper>
      <components.SafeAreaView>
        {renderHeader()}
        {renderContent()}
        {renderFooter()}
      </components.SafeAreaView>
    </components.MotionWrapper>
  );
};
