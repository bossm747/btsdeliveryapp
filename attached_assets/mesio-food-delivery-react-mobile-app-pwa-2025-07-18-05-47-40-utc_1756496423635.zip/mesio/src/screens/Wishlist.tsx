import React, {useEffect} from 'react';

import {items} from '@/items';
import {hooks} from '@/hooks';
import {stores} from '@/stores';
import {constants} from '@/constants';
import {components} from '@/components';

export const Wishlist: React.FC = () => {
  const {list: wishlist} = stores.useWishlistStore();

  const {navigate} = hooks.useRouter();

  useEffect(() => {
    if (wishlist.length === 0) {
      navigate(constants.routes.WISHLIST_EMPTY, {
        replace: true,
      });
    }
  }, [wishlist, navigate]);

  const renderHeader = () => {
    return (
      <components.Header
        showGoBack={true}
        title='Wishlist'
        showBasket={true}
      />
    );
  };

  const renderBottomBar = () => {
    return <components.BottomTabBar />;
  };

  const renderContent = () => {
    return (
      <main
        style={{
          marginTop: constants.sizes.HEADER_HEIGHT,
          marginBottom: constants.sizes.TAB_BAR_HEIGHT,
          padding: 20,
          overflowY: 'auto',
        }}
      >
        <ul style={{...constants.flex.FLEX_COLUMN, gap: 14}}>
          {wishlist.map((dish) => {
            return (
              <items.WishlistItem
                key={dish.id}
                dish={dish}
              />
            );
          })}
        </ul>
      </main>
    );
  };

  return (
    <components.MotionWrapper>
      <components.SafeAreaView>
        {renderHeader()}
        {renderContent()}
        {renderBottomBar()}
      </components.SafeAreaView>
    </components.MotionWrapper>
  );
};
