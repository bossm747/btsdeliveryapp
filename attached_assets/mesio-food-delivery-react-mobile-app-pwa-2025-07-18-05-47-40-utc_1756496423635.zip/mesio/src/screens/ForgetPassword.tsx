import React from 'react';

import {hooks} from '@/hooks';
import {constants} from '@/constants';
import {components} from '@/components';

export const ForgetPassword: React.FC = () => {
  const {navigate} = hooks.useRouter();

  const {form, handleChangeField} = hooks.useFormField({
    email: '',
  });

  const handleSubmit = () => {
    navigate(constants.routes.NEW_PASSWORD);
  };

  const renderHeader = () => {
    return (
      <components.Header
        showGoBack={true}
        title='Forgot Password'
      />
    );
  };

  const renderContent = () => {
    return (
      <main
        style={{
          marginTop: constants.sizes.HEADER_HEIGHT,
          padding: 20,
          width: '100%',
        }}
      >
        <p
          style={{
            marginBottom: 25,
            maxWidth: 302,
            textAlign: 'center',
            lineHeight: 1.5,
            marginLeft: 'auto',
            marginRight: 'auto',
          }}
        >
          Please enter your email address. You will receive a link to create a
          new password via email.
        </p>
        <components.Input
          placeholder='Email Address'
          containerStyle={{marginBottom: 20}}
          value={form.email}
          onClick={() => handleChangeField('email', 'Email Address')}
        />
        <components.Button
          label='Send'
          onClick={handleSubmit}
        />
      </main>
    );
  };

  return (
    <components.MotionWrapper>
      <components.SafeAreaView>
        {renderHeader()}
        {renderContent()}
      </components.SafeAreaView>
    </components.MotionWrapper>
  );
};
