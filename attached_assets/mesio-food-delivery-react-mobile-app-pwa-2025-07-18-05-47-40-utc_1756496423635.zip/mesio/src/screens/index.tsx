import {FAQ} from '@/screens/FAQ';
import {Home} from '@/screens/Home';
import {Shop} from '@/screens/Shop';
import {Dish} from '@/screens/Dish';
import {Order} from '@/screens/Order';
import {SignUp} from '@/screens/SignUp';
import {SignIn} from '@/screens/SignIn';
import {Profile} from '@/screens/Profile';
import {Reviews} from '@/screens/Reviews';
import {Wishlist} from '@/screens/Wishlist';
import {Checkout} from '@/screens/Checkout';
import {CartEmpty} from '@/screens/CartEmpty';
import {Onboarding} from '@/screens/Onboarding';
import {EditProfile} from '@/screens/EditProfile';
import {NewPassword} from '@/screens/NewPassword';
import {LeaveAReview} from '@/screens/LeaveAReview';
import {ShopCategory} from '@/screens/ShopCategory';
import {MyPromocodes} from '@/screens/MyPromocodes';
import {CommentReply} from '@/screens/CommentReply';
import {OrderHistory} from '@/screens/OrderHistory';
import {WishlistEmpty} from '@/screens/WishlistEmpty';
import {Notifications} from '@/screens/Notifications';
import {ChangePassword} from '@/screens/ChangePassword';
import {ForgetPassword} from '@/screens/ForgetPassword';
import {AccountCreated} from '@/screens/AccountCreated';
import {OrderSuccessful} from '@/screens/OrderSuccessful';
import {ConfirmationCode} from '@/screens/ConfirmationCode';
import {MyPromocodesEmpty} from '@/screens/MyPromocodesEmpty';
import {VerifyYourPhoneNumber} from '@/screens/VerifyYourPhoneNumber';
import {ForgotPasswordSentEmail} from '@/screens/ForgotPasswordSentEmail';

export const screens = {
  FAQ,
  Home,
  Dish,
  Shop,
  Order,
  SignIn,
  SignUp,
  Profile,
  Reviews,
  Wishlist,
  Checkout,
  CartEmpty,
  Onboarding,
  EditProfile,
  NewPassword,
  MyPromocodes,
  CommentReply,
  LeaveAReview,
  ShopCategory,
  OrderHistory,
  Notifications,
  WishlistEmpty,
  ForgetPassword,
  ChangePassword,
  AccountCreated,
  OrderSuccessful,
  ConfirmationCode,
  MyPromocodesEmpty,
  VerifyYourPhoneNumber,
  ForgotPasswordSentEmail,
};
