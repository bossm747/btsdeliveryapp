import React from 'react';

import {hooks} from '@/hooks';
import {constants} from '@/constants';
import {components} from '@/components';

export const ChangePassword: React.FC = () => {
  const {navigate} = hooks.useRouter();
  const {form, handleChangeField} = hooks.useFormField({
    oldPassword: '',
    newPassword: '',
    confirmPassword: '',
  });

  const handleUpdatePassword = () => {
    if (!form.oldPassword || !form.newPassword || !form.confirmPassword) {
      alert('Please fill in all fields.');
      return;
    }

    if (form.newPassword !== form.confirmPassword) {
      alert('New password and confirm password do not match.');
      return;
    }

    navigate(constants.routes.PROFILE, {
      replace: true,
    });
  };

  const renderHeader = () => {
    return (
      <components.Header
        showGoBack={true}
        title='Change Password'
      />
    );
  };

  const renderContent = () => {
    return (
      <main
        style={{
          marginTop: constants.sizes.HEADER_HEIGHT,
          paddingTop: 25,
          paddingLeft: 20,
          paddingRight: 20,
          paddingBottom: 20,
        }}
      >
        <div style={{...constants.flex.FLEX_COLUMN, gap: 11, marginBottom: 20}}>
          <components.Input
            placeholder='Old Password'
            value={form.oldPassword}
            onClick={() => handleChangeField('oldPassword', 'Old Password')}
          />
          <components.Input
            placeholder='New Password'
            value={form.newPassword}
            onClick={() => handleChangeField('newPassword', 'New Password')}
          />
          <components.Input
            placeholder='Confirm Password'
            value={form.confirmPassword}
            onClick={() =>
              handleChangeField('confirmPassword', 'Confirm Password')
            }
          />
        </div>
        <components.Button
          label='Save Now!'
          onClick={handleUpdatePassword}
        />
      </main>
    );
  };

  return (
    <components.MotionWrapper>
      <components.SafeAreaView>
        {renderHeader()}
        {renderContent()}
      </components.SafeAreaView>
    </components.MotionWrapper>
  );
};
