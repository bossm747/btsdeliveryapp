import React from 'react';

import {hooks} from '@/hooks';
import {constants} from '@/constants';
import {components} from '@/components';

export const CommentReply: React.FC = () => {
  const {navigate} = hooks.useRouter();
  const {form, handleChangeField} = hooks.useFormField({comment: ''});

  const handleSubmit = () => {
    navigate(-1);
  };

  const renderHeader = () => {
    return (
      <components.Header
        showGoBack={true}
        title='Reply'
      />
    );
  };

  const renderContent = () => {
    return (
      <main
        style={{
          marginTop: constants.sizes.HEADER_HEIGHT,
          paddingLeft: 20,
          paddingRight: 20,
          paddingTop: 20,
        }}
      >
        <h2
          style={{marginBottom: 10, fontSize: 16, textTransform: 'capitalize'}}
        >
          Write your reply
        </h2>
        <button
          style={{
            marginBottom: 20,
            borderRadius: 10,
            width: '100%',
            backgroundColor: constants.colors.LIGHT_GRAY_COLOR,
          }}
          value={form.comment}
          onClick={() => handleChangeField('comment', 'comment')}
        >
          <p
            style={{
              height: 127,
              width: '100%',
              padding: 14,
              border: 'none',
              fontSize: 16,
              color: '#748BA0',
              backgroundColor: 'transparent',
              resize: 'none',
            }}
          >
            {form.comment || 'Write your review here...'}
          </p>
        </button>
        <components.Button
          label='Submit Reply'
          onClick={() => {
            handleSubmit();
          }}
        />
      </main>
    );
  };

  return (
    <components.MotionWrapper>
      <components.SafeAreaView>
        {renderHeader()}
        {renderContent()}
      </components.SafeAreaView>
    </components.MotionWrapper>
  );
};
