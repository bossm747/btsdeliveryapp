import React from 'react';

import DoneSvg from '@/assets/svg/done.svg?react';

import {hooks} from '@/hooks';
import {constants} from '@/constants';
import {components} from '@/components';

export const ForgotPasswordSentEmail: React.FC = () => {
  const {navigate} = hooks.useRouter();

  const renderContent = () => {
    return (
      <main
        style={{
          padding: 20,
          ...constants.flex.FLEX_COLUMN,
          justifyContent: 'center',
          height: '100%',
          width: '100%',
        }}
      >
        <DoneSvg
          style={{
            marginLeft: 'auto',
            marginRight: 'auto',
            marginBottom: 36,
          }}
        />
        <h2
          style={{
            ...constants.typography.h2,
            textTransform: 'capitalize',
            marginBottom: 10,
            marginLeft: 'auto',
            marginRight: 'auto',
            color: constants.colors.SEA_GREEN_COLOR,
          }}
        >
          Password Successfully Reset!
        </h2>
        <p
          style={{
            maxWidth: 274,
            textAlign: 'center',
            fontSize: 16,
            marginLeft: 'auto',
            marginRight: 'auto',
            marginBottom: 20,
          }}
        >
          You can now log in with your new password.
        </p>
        <components.Button
          label='Take me to sign in'
          onClick={() => {
            navigate(constants.routes.SIGN_IN, {
              replace: true,
            });
          }}
        />
      </main>
    );
  };

  return (
    <components.MotionWrapper>
      <components.SafeAreaView>{renderContent()}</components.SafeAreaView>
    </components.MotionWrapper>
  );
};
