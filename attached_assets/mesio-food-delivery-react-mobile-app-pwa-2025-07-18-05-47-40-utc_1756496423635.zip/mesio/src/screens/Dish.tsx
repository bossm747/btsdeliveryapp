import React from 'react';
import {Link} from 'react-router-dom';

import StarSvg from '@/assets/svg/star.svg?react';

import {items} from '@/items';
import {hooks} from '@/hooks';
import {stores} from '@/stores';
import {ReviewType} from '@/types';
import {constants} from '@/constants';
import {components} from '@/components';

export const Dish: React.FC = () => {
  const {location} = hooks.useRouter();
  const {navigate} = hooks.useRouter();
  const {dishId} = location.state || {dishId: null};
  const {dish, isLoading} = hooks.useGetDish(dishId);
  const {
    list: wishlist,
    addToWishlist,
    removeFromWishlist,
  } = stores.useWishlistStore();
  const {showToast} = stores.useToastStore();
  const {list: cart, addToCart, removeFromCart} = stores.useCartStore();
  const {data: reviews, isLoading: reviewsIsLoading} = hooks.useGetReviews();

  if (isLoading || reviewsIsLoading) return <components.Loader />;

  const inCart = cart.find((item) => item.id === dish?.id);
  const quantity = inCart ? inCart.quantity : 0;
  const isInWishlist = wishlist.some((item) => item.id === dish?.id);

  const handleAddToCart = () => {
    if (dish) {
      addToCart(dish);

      if (quantity) {
        return;
      }

      showToast(`Added ${dish.name} to cart`);
    }
  };

  const renderHeader = () => {
    return (
      <components.Header
        showGoBack={true}
        showBasket={true}
        title='Dish Details'
      />
    );
  };

  const renderImage = () => {
    return (
      <div
        style={{
          position: 'relative',
          marginBottom: 10,
          paddingLeft: 20,
          paddingRight: 20,
        }}
      >
        <img
          src={dish?.image}
          alt={dish?.name}
          style={{
            width: '100%',
          }}
        />
        <button
          style={{
            position: 'absolute',
            top: 0,
            right: 0,
            zIndex: 10,
            padding: 10,
          }}
          onClick={(e) => {
            e.stopPropagation();
            e.preventDefault();
            if (dish) {
              if (isInWishlist) {
                removeFromWishlist(dish);
              } else {
                addToWishlist(dish);
              }
            }
          }}
        >
          <components.InWishlist
            fillColor={
              isInWishlist ? constants.colors.RED_COLOR : 'transparent'
            }
            strokeColor={
              isInWishlist
                ? constants.colors.RED_COLOR
                : constants.colors.TEXT_COLOR
            }
          />
        </button>
      </div>
    );
  };

  const renderNameAndDescription = () => {
    return (
      <section>
        <h1
          style={{
            fontSize: 18,
            color: constants.colors.MAIN_DARK_COLOR,
            fontWeight: 600,
            marginBottom: 7,
          }}
          className='number-of-lines-1'
        >
          {dish?.name}
        </h1>
        <p style={{fontSize: 16, lineHeight: 1.5, marginBottom: 14}}>
          {dish?.description}
        </p>
      </section>
    );
  };

  const renderPriceAndRating = () => {
    return (
      <section
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'flex-end',
          marginBottom: 20,
        }}
      >
        <span style={{fontSize: 24, color: '#FE724E', fontWeight: 700}}>
          ${dish?.price.toFixed(2)}
        </span>
        <Link
          to={constants.routes.REVIEWS}
          style={{
            marginBottom: 1,
            ...constants.flex.FLEX_ROW,
            gap: 5,
          }}
        >
          <StarSvg />
          <span>{reviews?.length} Review</span>
        </Link>
      </section>
    );
  };

  const renderButtons = () => {
    return (
      <div style={{marginBottom: 40}}>
        <components.Button
          label={`Add to Cart - (${inCart ? inCart.quantity : 0})`}
          containerStyle={{marginBottom: 10}}
          onClick={() => {
            handleAddToCart();
          }}
        />
        {inCart && (
          <components.Button
            label={'Remove from Cart'}
            colorScheme='secondary'
            onClick={() => {
              if (dish) {
                removeFromCart(dish);
              }
            }}
          />
        )}
      </div>
    );
  };

  const renderReviews = () => {
    return (
      <div>
        <components.BlockHeading
          title={`Happy clients say (${reviews?.length || 0})`}
          onClick={() => {
            navigate(constants.routes.REVIEWS);
          }}
          containerStyle={{paddingLeft: 0, paddingRight: 0, marginBottom: 14}}
        />
        <ul style={{...constants.flex.FLEX_COLUMN, gap: 14, marginBottom: 20}}>
          {reviews.slice(0, 3).map((review: ReviewType) => {
            return (
              <items.ReviewItem
                key={review.id}
                review={review}
              />
            );
          })}
        </ul>
        <components.Button
          label='Leave a Review'
          onClick={() => {
            navigate(constants.routes.LEAVE_A_REVIEW);
          }}
        />
      </div>
    );
  };

  const renderContent = () => {
    return (
      <main
        style={{
          marginTop: constants.sizes.HEADER_HEIGHT,
          paddingLeft: 20,
          paddingRight: 20,
          paddingBottom: 20,
          paddingTop: 25,
          overflowY: 'auto',
        }}
      >
        {renderImage()}
        {renderNameAndDescription()}
        {renderPriceAndRating()}
        {renderButtons()}
        {renderReviews()}
      </main>
    );
  };

  return (
    <components.MotionWrapper>
      <components.SafeAreaView>
        {renderHeader()}
        {renderContent()}
      </components.SafeAreaView>
    </components.MotionWrapper>
  );
};
