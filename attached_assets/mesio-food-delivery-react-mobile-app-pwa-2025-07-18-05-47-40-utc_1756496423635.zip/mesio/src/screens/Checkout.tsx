import React from 'react';

import {hooks} from '@/hooks';
import {stores} from '@/stores';
import {constants} from '@/constants';
import {components} from '@/components';

export const Checkout: React.FC = () => {
  const {list: cart, total} = stores.useCartStore();
  const {navigate} = hooks.useRouter();

  const {form, handleChangeField} = hooks.useFormField({
    fullName: '',
    address: '',
    phoneNumber: '',
    cardNumber: '',
    expiryDate: '',
    cvv: '',
  });

  const handlePlaceOrder = () => {
    navigate(constants.routes.ORDER_SUCCESSFUL, {replace: true});
  };

  const renderHeader = () => {
    return (
      <components.Header
        showGoBack={true}
        title='Checkout'
      />
    );
  };

  const renderOrderSummary = () => {
    return (
      <section
        style={{
          ...constants.styles.boxShadow,
          padding: 20,
          borderRadius: 10,
          marginBottom: 30,
        }}
      >
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            marginBottom: 14,
            paddingBottom: 14,
            borderBottom: '1px solid #f0f0f0ff',
          }}
        >
          <h4
            style={{
              fontSize: 18,
              color: constants.colors.MAIN_DARK_COLOR,
              textTransform: 'capitalize',
            }}
          >
            my order
          </h4>
          <span
            style={{
              fontSize: 18,
              color: constants.colors.MAIN_DARK_COLOR,
              textTransform: 'capitalize',
            }}
          >
            ${total.toFixed(2)}
          </span>
        </div>
        <ul style={{display: 'flex', flexDirection: 'column', gap: 6}}>
          {cart.map((dish, index) => (
            <div
              key={index}
              style={{
                display: 'flex',
                justifyContent: 'space-between',
              }}
            >
              <span style={{fontSize: 14}}>{dish.name}</span>
              <span style={{fontSize: 14}}>
                {dish.quantity} x ${dish.price.toFixed(2)}
              </span>
            </div>
          ))}
        </ul>
      </section>
    );
  };

  const renderShippingDetails = () => {
    return (
      <section style={{marginBottom: 20}}>
        <h4 style={{marginBottom: 14}}>Shipping Details</h4>
        <components.Input
          placeholder='Full Name'
          value={form.fullName}
          containerStyle={{marginBottom: 10}}
          onClick={() => handleChangeField('fullName', 'fullName')}
        />
        <components.Input
          placeholder='Address'
          containerStyle={{marginBottom: 10}}
          value={form.address}
          onClick={() => handleChangeField('address', 'address')}
        />
        <components.Input
          placeholder='Phone Number'
          containerStyle={{marginBottom: 10}}
          value={form.phoneNumber}
          onClick={() => handleChangeField('phoneNumber', 'phoneNumber')}
        />
      </section>
    );
  };

  const renderCardDetails = () => {
    return (
      <section style={{marginBottom: 20}}>
        <p style={{marginBottom: 14}}>Card Details</p>
        <div
          style={{
            display: 'flex',
            flexDirection: 'column',
            gap: 10,
          }}
        >
          <components.Input
            value={form.cardNumber}
            placeholder='Enter your card number'
            onClick={() => handleChangeField('cardNumber', 'Card Number')}
          />
          <components.Input
            value={form.expiryDate}
            placeholder='MM/YY'
            onClick={() => handleChangeField('expiryDate', 'MM/YY')}
          />
          <components.Input
            value={form.cvv}
            placeholder='CVV'
            onClick={() => handleChangeField('cvv', 'CVV')}
          />
        </div>
      </section>
    );
  };

  const renderButton = () => {
    return (
      <components.Button
        label='Place Order'
        onClick={() => {
          handlePlaceOrder();
        }}
      />
    );
  };

  const renderContent = () => {
    return (
      <main
        style={{
          marginTop: constants.sizes.HEADER_HEIGHT,
          padding: 20,
          overflowY: 'auto',
        }}
      >
        {renderOrderSummary()}
        {renderShippingDetails()}
        {renderCardDetails()}
        {renderButton()}
      </main>
    );
  };

  return (
    <components.MotionWrapper>
      <components.SafeAreaView>
        {renderHeader()}
        {renderContent()}
      </components.SafeAreaView>
    </components.MotionWrapper>
  );
};
