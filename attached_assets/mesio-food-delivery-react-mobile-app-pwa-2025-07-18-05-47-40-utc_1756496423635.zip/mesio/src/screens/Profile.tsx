import React from 'react';

import FaqSvg from '@/assets/svg/faq.svg?react';
import LogoutSvg from '@/assets/svg/logout.svg?react';
import PromocodeSvg from '@/assets/svg/promocode.svg?react';
import ProfileOrderSvg from '@/assets/svg/profile-order.svg?react';
import NotificationsSvg from '@/assets/svg/notification.svg?react';

import {hooks} from '@/hooks';
import {items} from '@/items';
import {constants} from '@/constants';
import {components} from '@/components';

export const Profile: React.FC = () => {
  const {navigate} = hooks.useRouter();

  const renderHeader = () => {
    return <components.Header title='Profile' />;
  };

  const renderBottomBar = () => {
    return <components.BottomTabBar />;
  };

  const renderContent = () => {
    return (
      <main
        style={{
          marginTop: constants.sizes.HEADER_HEIGHT,
          paddingTop: 25,
          paddingLeft: 20,
          paddingRight: 20,
          paddingBottom: 20,
          overflowY: 'auto',
          marginBottom: constants.sizes.TAB_BAR_HEIGHT,
        }}
      >
        <div
          style={{marginBottom: 34}}
          onClick={() => navigate(constants.routes.EDIT_PROFILE)}
        >
          <img
            src='https://george-fx.github.io/mesio-data/users/01.jpg'
            alt='User Avatar'
            style={{
              width: 60,
              height: 60,
              borderRadius: '50%',
              marginBottom: 12,
              display: 'block',
              marginLeft: 'auto',
              marginRight: 'auto',
            }}
          />
          <h2
            style={{
              fontWeight: 700,
              fontSize: 16,
              textAlign: 'center',
              textTransform: 'capitalize',
              marginBottom: 5,
              color: constants.colors.SEA_GREEN_COLOR,
            }}
          >
            Kristin Watsan
          </h2>
          <span
            style={{
              textAlign: 'center',
              display: 'block',
              color: constants.colors.TEXT_COLOR,
            }}
          >
            +880123 456 789
          </span>
        </div>
        <div style={{...constants.flex.FLEX_COLUMN, gap: 18}}>
          <items.ProfileMenuItem
            title='Order History'
            icon={<ProfileOrderSvg />}
            to={constants.routes.ORDER_HISTORY}
            description='Review Your Order History'
          />
          <items.ProfileMenuItem
            title='Notifications'
            icon={<NotificationsSvg />}
            to={constants.routes.NOTIFICATIONS}
            description='Your Notifications'
          />
          <items.ProfileMenuItem
            title='FAQ'
            icon={<FaqSvg />}
            to={constants.routes.FAQ}
            description='Frequently Questions'
          />
          <items.ProfileMenuItem
            title='My Promocodes'
            icon={<PromocodeSvg />}
            to={constants.routes.MY_PROMOCODES}
            description='Your Promocodes'
          />
          <items.ProfileMenuItem
            title='My Promocodes Empty'
            icon={<PromocodeSvg />}
            to={constants.routes.MY_PROMOCODES_EMPTY}
            description='Your Promocodes'
          />
          <items.ProfileMenuItem
            title='Logout'
            icon={<LogoutSvg />}
            to={constants.routes.SIGN_IN}
            description='Logout from your account'
          />
        </div>
      </main>
    );
  };

  return (
    <components.MotionWrapper>
      <components.SafeAreaView>
        {renderHeader()}
        {renderContent()}
        {renderBottomBar()}
      </components.SafeAreaView>
    </components.MotionWrapper>
  );
};
