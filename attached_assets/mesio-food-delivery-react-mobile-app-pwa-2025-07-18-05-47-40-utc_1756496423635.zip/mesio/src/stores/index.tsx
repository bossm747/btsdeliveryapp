import {useCartStore} from '@/stores/useCartStore';
import {useToastStore} from '@/stores/useToastStore';
import {useModalStore} from '@/stores/useModalStore';
import {useWishlistStore} from '@/stores/useWishlistStore';

export const stores = {
  useCartStore,
  useModalStore,
  useToastStore,
  useWishlistStore,
};
